package com.browser.automation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LaunchBrowserAndMax {

	
	@Test
	public void launchBrowser() {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.edge.driver", "C:\\Users\\kowsalyas\\Drivers\\msedgedriver.exe");

		WebDriver driver = new EdgeDriver();

		driver.manage().window().maximize();

		driver.get("https://demoqa.com/");
		
		Assert.assertEquals(false, true);
		driver.manage().window().minimize();
	}

}
