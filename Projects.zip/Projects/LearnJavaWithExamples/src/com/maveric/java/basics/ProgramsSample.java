package com.maveric.java.basics;

/*public class ProgramsSample {
	public static void main(String[] args) {
		int number = 120;

		if(number%2==0) {
			System.out.println("Number is a even number");
		}else {
			System.out.println("Number is not a even number");
		}
	}
}*/

//public class ProgramsSample {
//	public static void main(String[] args) {
//		int a = 10;
//		int b = 15;
//		int c = a+b;
//		System.out.println("The sum value is "+b);
//	}
//}

//public class ProgramsSample {
//	public static void main(String[] args) {
//		float val1 = 100;
//		float val2 = 10;
//		float val3 = val1/val2;
//		System.out.println(val3);
//	}
//}

//public class ProgramsSample {
//	public static void main(String[] args) {
//		char data1 = 'a';
//		char data2 = 'a';
//		
//		System.out.println(data1==data2);
//	}
//}


//public class ProgramsSample {
//	public static void main(String[] args) {
//		int num1 = 135;
//		int num2 = 145;
//		int num3 = 136;
//
//
//		if(num1>=num2) {
//			System.out.println(num1);
//		}else if(num2>num2) {
//			System.out.println(num2);
//		}else if(num1!=num3) {
//			System.out.println(num3);
//		}else {
//			System.out.println(num1+num2);
//		}
//	}
//}

public class ProgramsSample {
	public static void main(String[] args) {
		int numberOfNotes = 10;

		switch (numberOfNotes){
		case 5: 
			System.out.println("Person has 5 notes");
			break;
		case 10: 
			System.out.println("Person has 10 notes");	
		case 15:
			System.out.println("Person has 15 notes");
			break;
		default:
			System.out.println("Person has no notes");
			
		}
	}
}

//public class ProgramsSample {
//	public static void main(String[] args) {
//		String classString = "College 1st year";
//
//		switch (classString){
//		case "College 1st Year": 
//			System.out.println("Inside 1st case");
//			break;
//			
//		case "college 1st year": 
//			System.out.println("Inside 2nd case");
//			break;
//			
//		case "College 1st year":
//			System.out.println("Inside 3rd case");
//			break;
//			
//		default:
//			System.out.println("Inside default case");
//			break;
//			
//		}
//	}
//}

/*public class ProgramsSample {
	public static void main(String[] args) {
		int count=0;
		for(int i=0;i<=100;i=i+1) {
			count=count+1;
		}
		System.out.println(count);
	}
}*/

//public class ProgramsSample {
//	public static void main(String[] args) {
//		int count=20;
//		for(int i=10;i>=count;i--) {
//			System.out.println(i);
//		}
//	}
//}

//public class ProgramsSample {
//	public static void main(String[] args) {
//		int count=20;
//		for(int i=10;i>=count;i--) {
//			System.out.println(i);
//		}
//	}
//}

//public class ProgramsSample {
//	public static void main(String[] args) {
//		int count=20;
//		for(int i=10;i>=count;i--) {
//			System.out.println(i);
//		}
//	}
//}



/*
int numberOfNotes = 10;

switch (numberOfNotes){
case 5: 
	System.out.println("Person has 5 notes");
	break;
case 10: 
	System.out.println("Person has 10 notes");
	break;
case 15:
	System.out.println("Person has 15 notes");
	break;
default:
	System.out.println("Person has no notes");
	break;
}*/



//	String name1 = "John";
//	String name2 = "Peter";
//	ProgramsSample programsSample = new ProgramsSample();
//	programsSample.readTheData(name2, name2);
//}
//
//public void readTheData(String name1, String name2) {
//	System.out.println(name1 +"is friend of "+name2);
//}