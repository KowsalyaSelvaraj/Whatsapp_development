package com.maveric.java.basics;

import java.util.Scanner;

public class Friends {


	//Inbuild Method
	public static void main(String[] args) {

		int gangCount = 5;
		String teamLeadString = "NP";
		String comedianString = "VigneshKanth";
		String talkativeMemberString = "Nandhini";
		String webSeriesNameString = "AA HA Kalyanam";
		int budget = 0;

		System.out.println(teamLeadString);

		//reading values from user
		Scanner sc= new Scanner(System.in); 
		System.out.println("Please Enter Budget");
		budget = sc.nextInt();

		//Constructor
		Friends friends = new Friends();

		//Conditional Statements
		if(budget>50000) {
			friends.allActInWebSeries();
		}else {
			friends.onlyFewActInWebSeries(teamLeadString,talkativeMemberString);
		}

		int webSeriesNoOfViews = friends.getNoOfViews(webSeriesNameString);
		System.out.println("Webseries "+webSeriesNameString+" has views of "+webSeriesNoOfViews);
	}

	//methods
	public void allActInWebSeries() {
		System.out.println("Friends all together act in webseries");
	}

	//pass arguments to methods
	public void onlyFewActInWebSeries(String LeadRole, String femaleLeadRole) {
		System.out.println("Due to budget only "+LeadRole+" and "+femaleLeadRole+" acts in the webseries");
	}

	//method with return statement
	public int getNoOfViews(String webSeriesNameString) {
		int numberOfViews = 0;
		if(webSeriesNameString.equals("AA HA Kalyanam")) {
			numberOfViews = 673000;
		}else if (webSeriesNameString.equals("kaluri Salai")) {
			numberOfViews = 450000;
		}
		return numberOfViews;
	}
}
