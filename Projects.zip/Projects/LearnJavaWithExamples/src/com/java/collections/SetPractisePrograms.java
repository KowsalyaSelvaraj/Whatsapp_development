package com.java.collections;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class SetPractisePrograms {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet<String> hashSet = new HashSet<String>();

		hashSet.add("Monday");
		hashSet.add("Tuesday");
		hashSet.add("Sunday");
		hashSet.add("Wednesday");
		hashSet.add("Sunday");

		System.out.println("Hash Set");
		for(String dayString : hashSet) {
			System.out.println(dayString);
		}	

	
		LinkedHashSet<String> linkedhashSet = new LinkedHashSet<String>();

		linkedhashSet.add("Monday");
		linkedhashSet.add("Tuesday");
		linkedhashSet.add("Sunday");

		linkedhashSet.add("Wednesday");
		linkedhashSet.add("Sunday");
		linkedhashSet.add(null);

		System.out.println("\nLinked HS");
		for(String dayString : linkedhashSet) {
			System.out.println(dayString);
		}	
//
		TreeSet<String> treeSet = new TreeSet<String>();

		treeSet.add("A");
		treeSet.add("C");
		treeSet.add("B");

		treeSet.add("B");
		treeSet.add("K");
		//treeSet.add(null);

		System.out.println();
		System.out.println("treeSet HS");
		for(String dayString : treeSet) {
			System.out.println(dayString);
		}	
		
		//reverse order 
		TreeSet<String> treeSet1 = new TreeSet<String>(Collections.reverseOrder());

		treeSet1.add("A");
		treeSet1.add("C");
		treeSet1.add("B");

		treeSet1.add("B");
		treeSet1.add("K");
		//treeSet.add(null);

		System.out.println();
		System.out.println("treeSet HS");
		for(String dayString : treeSet1) {
			System.out.println(dayString);
		}	
	}
}
