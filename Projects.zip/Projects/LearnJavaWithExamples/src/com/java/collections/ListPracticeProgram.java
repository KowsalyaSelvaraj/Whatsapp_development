package com.java.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;



public class ListPracticeProgram {

	public static void main(String[] args) {

		//Slide number 114 

		ArrayList numbersArrayList = new ArrayList<>();

		numbersArrayList.add("StringVariable");
		numbersArrayList.add(2356);
		numbersArrayList.add('D');

		numbersArrayList.remove(1);
		for(Object var1 : numbersArrayList) {
			System.out.println(var1);
		}

		ArrayList<Integer> numbersArrayList1 = new ArrayList<Integer>();

		numbersArrayList1.add(100);
		numbersArrayList1.add(200);
		numbersArrayList1.add(300);
		numbersArrayList1.add(200);
		numbersArrayList1.add(null);
		numbersArrayList1.add(750);
		numbersArrayList1.add(850);

		//iterate arrayList
		for(Integer num1 : numbersArrayList1) {
			System.out.println(num1);
		}

		for(int i=0;i<numbersArrayList1.size();i++) {
			System.out.println("Get value "+i+" from array list=>"+numbersArrayList1.get(i));
		}

		numbersArrayList1.set(6, 560);

		System.out.println(numbersArrayList1);
		//
		//		//index of 
		System.out.println("Index of "+numbersArrayList1.indexOf(200));

		System.out.println("Last Index of "+numbersArrayList1.lastIndexOf(200));

		//		//remove elements
		numbersArrayList1.remove(null);

		for(int i=0;i<numbersArrayList1.size();i++) {
			System.out.println("Get value "+i+" from array list=>"+numbersArrayList1.get(i));
		}

		numbersArrayList1.remove(1);
		System.out.println();
		for(int i=0;i<numbersArrayList1.size();i++) {
			System.out.println("Get value "+i+" from array list=>"+numbersArrayList1.get(i));
		}
		//		//clear the arrayList
		//	numbersArrayList1.clear();
		System.out.println(numbersArrayList1.isEmpty());
		//
		ArrayList<Integer> numbersArrayList2 = new ArrayList<Integer>();

		numbersArrayList2.add(50);
		numbersArrayList2.add(25);

		numbersArrayList1.addAll(numbersArrayList2);

		System.out.println(numbersArrayList1);


		if(numbersArrayList2.contains(50)) {
			System.out.println("50 is available in list ");
		}else {
			System.out.println("50 not in list");
		}
		//
		Iterator<Integer> iterator = numbersArrayList1.iterator();
		int i=0;
		while (iterator.hasNext()) {
			System.out.println("position "+i);
			System.out.println("Iterator list => "+iterator.next());
			i++;
		}
		//
		//		
		//		
		//		
		LinkedList<String> colorsLinkedList = new LinkedList<String>();


		colorsLinkedList.add("Red");
		colorsLinkedList.add("Blue");
		colorsLinkedList.add(null);
		colorsLinkedList.add("Blue");

		for (Iterator iterator2 = colorsLinkedList.iterator(); iterator2.hasNext();) {
			String string = (String) iterator2.next();

			System.out.println(string);
		}

		System.out.println(colorsLinkedList.getFirst());
		
		System.out.println(colorsLinkedList.removeLast());

		for (Iterator iterator2 = colorsLinkedList.iterator(); iterator2.hasNext();) {
			String string = (String) iterator2.next();

			System.out.println(string);
		}


	}
}