package com.java.collections;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapsPractise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Map -> hashmap, LinkedHashmap, TreeMap

		//	HashMap<K, V>	
		//hashmap
		//1. Duplicate key values are not allowed -> if duplicate keys are given value will be overwritten
		//2. Duplicate values are allowed
		//3. Null value in key is allowed but only once
		//4. null value in Value is allowed

		HashMap<Integer, String> studentNamesHashMap = new HashMap<Integer, String>();

		studentNamesHashMap.put(108, "Pushpa");
		studentNamesHashMap.put(100, "Kowsalya");
		studentNamesHashMap.put(105, "Gopal");
		studentNamesHashMap.put(105, "Priya");
		System.out.println(studentNamesHashMap);
		//
		//		//read with value only with key
		//		//to read the content use the key for reading it.
		System.out.println("Read the data with Key =>"+studentNamesHashMap.get(105));
		//
		//		//duplicate key and value
		studentNamesHashMap.put(105, "Madhav A");
		studentNamesHashMap.put(106, "Madhav B");
		studentNamesHashMap.put(107, "Madhav B");
//		//
		System.out.println("Read the data with Key 105=>"+studentNamesHashMap.get(105));
		System.out.println("Read the data with Key 106=>"+studentNamesHashMap.get(106));
		System.out.println("Read the data with Key 107 =>"+studentNamesHashMap.get(107));
//		//
//		//		//Null value 
		studentNamesHashMap.put(null, "Johan");
		studentNamesHashMap.put(null, "Nisha");
//		//
//		//
		System.out.println("Read the data with Key null =>"+studentNamesHashMap.get(null));

		System.out.println(studentNamesHashMap);
//		//
//		//		//methods in maps
//		//		//containsKey, containsValue
		System.out.println("Contains Key  =>"+studentNamesHashMap.containsKey(107)); //true
		System.out.println("Contains Key  =>"+studentNamesHashMap.containsKey(109)); //false

		System.out.println("Contains Value Johan   =>"+studentNamesHashMap.containsValue("Johan")); //false
		System.out.println("Contains Value Nisha  =>"+studentNamesHashMap.containsValue("Nisha")); //true

//		//
//		//		//Isempty
		
		System.out.println("IS the map empty => "+studentNamesHashMap.isEmpty());
		
		//studentNamesHashMap.clear();
		System.out.println("IS the map empty => "+studentNamesHashMap.isEmpty());
//		//
//		//
//		//		//keySet and Values
		System.out.println(studentNamesHashMap.values());
		System.out.println(studentNamesHashMap.keySet());
		System.out.println(studentNamesHashMap.entrySet());
//		//
//		//
//		//		//looping in Map
		for (Map.Entry<Integer, String> mapEntry : studentNamesHashMap.entrySet()) {
			System.out.println(mapEntry);

			System.out.println("Key "+mapEntry.getKey() +"=> value "+mapEntry.getValue());

		}
//		//
//		//		//remove
		studentNamesHashMap.remove(null);

		System.out.println("\n//after removing ");
		//looping in Map
		for (Map.Entry<Integer, String> mapEntry : studentNamesHashMap.entrySet()) {

			System.out.println("Key "+mapEntry.getKey() +"=> value "+mapEntry.getValue());

		}
//
//		//
//		//		//replace
		studentNamesHashMap.replace(107, "Madhav C");
		studentNamesHashMap.replace(100, "Kowsalya","Kowsalya S");
//
//
		System.out.println("\n//after replacing ");
		//looping in Map
		for (Map.Entry<Integer, String> mapEntry : studentNamesHashMap.entrySet()) {

			System.out.println("Key "+mapEntry.getKey() +"=> value "+mapEntry.getValue());

		}
//		//
//		//		//clear;
//		studentNamesHashMap.clear();
//
//		System.out.println("\n//after clearing ");
//		//looping in Map
//		System.out.println("IS the map empty => "+studentNamesHashMap.isEmpty());
//		System.out.println(studentNamesHashMap.get(100));
//		for (Map.Entry<Integer, String> mapEntry : studentNamesHashMap.entrySet()) {
//
//			System.out.println("Key "+mapEntry.getKey() +"=> value "+mapEntry.getValue());
//
//		}
//		//
//		//		//Linked Hash
//		//		//maintains order
//		//
		LinkedHashMap<String,String> fruitHashMap = new LinkedHashMap<String, String>();

		fruitHashMap.put("Apple", "Red");
		fruitHashMap.put("Orange", "Orange");
		fruitHashMap.put("Papaya","Orange");
		fruitHashMap.put("Grapes","Purple");

		System.out.println("\fruites map");
		for (Map.Entry<String, String> mapEntry : fruitHashMap.entrySet()) {

			System.out.println("Key "+mapEntry.getKey() +"=> value "+mapEntry.getValue());

		}

//		//
//		//		//treemap
//		//		//maintains sorting order
//		//		//Null value not allowed
//		//		//Duplicate key value not allowed
//		//
		TreeMap<String,Integer> rankingMap = new TreeMap<String, Integer>();

		rankingMap.put("Mercury", 10);
		rankingMap.put("Venus", 2);
		rankingMap.put("Earth",1);
		//rankingMap.put(null, 5);

		System.out.println("\ntree map" + rankingMap);
		for(Map.Entry<String, Integer> mapEntry : rankingMap.entrySet()) {
			System.out.println("Key "+mapEntry.getKey() +"=> value "+mapEntry.getValue());

		}
		
		//reverse Order
		TreeMap<String,Integer> rankingMap1 = new TreeMap<String, Integer>(Collections.reverseOrder());

		rankingMap1.put("Mercury", 10);
		rankingMap1.put("Venus", 2);
		rankingMap1.put("Earth",1);
		//rankingMap.put(null, 5);

		System.out.println("\ntree map" + rankingMap1);
		for(Map.Entry<String, Integer> mapEntry : rankingMap1.entrySet()) {
			System.out.println("Key "+mapEntry.getKey() +"=> value "+mapEntry.getValue());

		}
	}

}

