package com.java.string.manipulation;

public class StringCreationDemo {

	public static void main(String[] args) {

		//Ways of Creating String

		//Way 1 :
		String word1 = "Chocolate";
		String word2 = "Chocolate";

		//word1 = word2;
		if(word1==word2) {
			System.out.println("word1 and word2 Strings are in same memory space");
		}else {
			System.out.println("word1 and word2 Strings are in different memory space");
		}

		//Way 2 
		String word3 = new String("Chocolate");
				
		if(word1==word3) {
			System.out.println("word1 and word3 Strings are in same memory space");
		}else {
			System.out.println("word1 and word3 Strings are in different memory space");
		}
		
		String word4 = word1;
		
		if(word1==word4) {
			System.out.println("word1 and word4 Strings are in same memory space");
		}else {
			System.out.println("word1 and word4 Strings are in different memory space");
		}
		
		//		
		System.out.println("word1 memory location => "+System.identityHashCode(word1));
		System.out.println("word2 memory location => "+System.identityHashCode(word2));
		System.out.println("word3 memory location => "+System.identityHashCode(word3));
		
		
		
		
		//compareStringValue
		
		String s1 = "Letter to you";
		String s2 = "Letter TO you";
		
		if(s1.equals(s2)) {
			System.out.println("both are equal");
		}else if(s1.equalsIgnoreCase(s2)) {
			System.out.println("both are equal case insensitive ");
		}else {
			System.out.println("both are not equal");
		}
		
		
		
		
	}

}
