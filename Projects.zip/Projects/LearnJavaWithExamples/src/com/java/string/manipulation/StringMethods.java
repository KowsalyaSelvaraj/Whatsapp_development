package com.java.string.manipulation;

public class StringMethods {

	public static void main(String[] args) {

		String nameString4 = "I like to watch movie in netflix";

		//to find length
		System.out.println("Length of the string => "+nameString4.length());

		//to find character at specific position 
		System.out.println("Character at 1 => "+nameString4.charAt(0));

//		//to find the character at last position 
		System.out.println("Character at last => "+nameString4.charAt(nameString4.length()-1));
//
//		//to check if a word is available in string
		System.out.println("Contains =>"+nameString4.contains("netflix"));
//
		System.out.println("Contains not =>"+nameString4.contains("Brother"));
//
//		//to remove the spaces in front and end
		String nameString5 = " the string is displayed in Ui ";
		System.out.println("remove space =>"+nameString5.trim()+"FE");
//
//
//
//
		String nameString6  = new String("I am going to Meet my friend");
//
//		//print each character
//
		char[] charArray = nameString6.toCharArray();

		System.out.println(charArray);
		for(char c : charArray) {
			System.out.print(c+" ");
		}
		System.out.print("\n");
		for(char c : charArray) {
			System.out.print((c+" ").trim());
		}
		
		System.out.print("\n");
//
//		//change the case of String
		System.out.println("\nto upper case "+nameString6.toUpperCase());
		System.out.println("to lower case "+nameString6.toLowerCase());
//
		System.out.println("Original String "+nameString6);

		String toLowerCaseString = nameString6.toLowerCase();
		System.out.println("Store the converted string to new string and then print "+toLowerCaseString);
		System.out.print("\n");
		
		//String Builder
		StringBuilder stringBuilder = new StringBuilder(toLowerCaseString);
		
		stringBuilder.reverse();
		
		System.out.println("Revered word "+stringBuilder);
		
//		//	I   a m   g o i n g    t   o    m  e  e  t     m   y     f r   i  e n  d 
//		//	0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 
//
//		//find the position of a string 
//
		System.out.println("\nIndex of I "+nameString6.indexOf("I"));
		System.out.println("Index of e from 14 "+nameString6.indexOf("e", 14));
		System.out.println("Last index of i "+nameString6.lastIndexOf("i"));
		System.out.println("Last index of i from 15 =>"+nameString6.lastIndexOf("i",26));

		
//		//Find the subString 
		System.out.println("\nSubString of NameString6 =>"+ nameString6.substring(15));
		System.out.println("SubString of NameString6 =>"+ nameString6.substring(15,20));

//		//replace words
		System.out.println("\nReplace a by # in  NameString6 =>"+ nameString6.replace('e','#'));
		System.out.println("Replace word by * in NameString6 =>"+ nameString6.replace("my","****"));

		
//		//check whether the string starts with and ends with 
		System.out.println("\nCheck String startsWith I =>"+ nameString6.startsWith("I"));
		System.out.println("Check String endsWith friend =>"+ nameString6.endsWith("friend"));

		System.out.println("\nCheck String startsWith A =>"+ nameString6.startsWith("A"));
		System.out.println("Check String endsWith hello =>"+ nameString6.endsWith("hello"));

//		//Split and join String
		System.out.println("Split the String");
		String[] splitStrings = nameString6.split(" ");

		for(int i=0;i<splitStrings.length;i++) {
			System.out.println("Position is "+i+" and data is "+splitStrings[i]);
		}
		
		System.out.println("Split the String");
		String[] splitStrings1 = ("Go.to.Office.in.cab").split("[.]");

		for(int i=0;i<splitStrings1.length;i++) {
			System.out.println("Position is "+i+" and data is "+splitStrings1[i]);
		}

		String dateString = String.join("/", "DD","MMM","YYYY");
		System.out.println("\nString created with Join "+dateString);
		
		
		
	}

}
