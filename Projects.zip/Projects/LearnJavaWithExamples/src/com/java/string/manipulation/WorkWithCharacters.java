package com.java.string.manipulation;

public class WorkWithCharacters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Find whether the character is number or digit or a
		String string1 = "I am 23 plann##ing 33,, to buy 1 house";
		
		char[] charArray = string1.toCharArray();
		
		for(int i=0;i<charArray.length;i++) {
			
			if(Character.isDigit(charArray[i])){
				System.out.println(charArray[i]+" is Digit");
			}else if(Character.isLetter(charArray[i])) {
				System.out.println(charArray[i]+" is Alphabet");
			}
		}
		
		char letter = 'a';
		
		letter++;
		System.out.println(letter);
	}

}
