package com.java.loops;

public class WhileLoopDemo {

	public static void main(String[] args) {
		

		//While loop example
		//Scenario 1: You are in your 12 std and you need to write 5 revision exams before you write your 
		//final board exams.
		//consider after half yearly exam. 
		
		int numberOfRevisionExams = 0;
		
		boolean finalExam = false;
		
		while(finalExam==false) {
			
			if(numberOfRevisionExams>=5) {
				finalExam = true;
				System.out.println("\nNo of revision exams completed = "+numberOfRevisionExams+"\nWrite Final Exam : "+finalExam);
			}else {
				numberOfRevisionExams++;
				System.out.println("Revision exam number : "+numberOfRevisionExams);
			}
		}
		
		//Scenario 2:
		int n=5;
		int i=0;
		while(i<=n) {
			System.out.println("Value of I is "+i);
			i++;
		}
	}

}
