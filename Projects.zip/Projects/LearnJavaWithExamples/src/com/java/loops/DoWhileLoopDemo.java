package com.java.loops;

public class DoWhileLoopDemo {

	public static void main(String[] args) {
		
		//Do While Loop Example

		//Scenario 1 : In you college there is a Master JD who allows student inside the class only once 
		//even if the assignment given yesterday was not completed
		
		boolean isAssignmentCompleted = false;
		
		do {
			
			//1st time you will not be checked whether you have completed the assignment.
			System.out.println("Inside do while loop");
			
		}while(isAssignmentCompleted==true);
		
		
		//Scenario 2 : 
		int n=5;
		int i=0;
		
		do {
			System.out.println("Value of i is "+i);
			i++;
		}while(i<=n);
	}

}
