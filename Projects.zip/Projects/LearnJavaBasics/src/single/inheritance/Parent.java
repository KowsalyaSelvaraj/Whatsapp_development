package single.inheritance;

public class Parent {


	//process of acquiring the properties of parent
	//use extents keyword for inheriting

	String fatherNameString  = "Prabakar";
	String motherNameString = "Raji";

	public void provideFood() {

		System.out.println("Parents take care of food");

	}

	public void provideSchoolEducation() {

		System.out.println("Parents pay school fees and join child in school");

	}
	
	public void provideCollegeEducation() {

		System.out.println("Parents wants child to join in engineering college");

	}
	
}
