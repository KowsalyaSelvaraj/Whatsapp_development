package single.inheritance;

public class RunnerClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Parent child = new Child();
		
	//	child.myparentDetails();
		child.provideFood();
		child.provideSchoolEducation();
		child.provideCollegeEducation();
		
	}

}
