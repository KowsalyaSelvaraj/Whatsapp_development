package single.inheritance;

public class Child extends Parent{

	String childNameString = "";
	
	public void myparentDetails() {
		System.out.println("My father name is  "+fatherNameString);
		System.out.println("My mother name is  "+motherNameString);
	}
	
	//method overriding
	public void provideCollegeEducation() {
		
		System.out.println("I will join viscom only not engineering");
	}
	
}
