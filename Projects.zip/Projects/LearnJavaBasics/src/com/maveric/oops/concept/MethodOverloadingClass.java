package com.maveric.oops.concept;

public class MethodOverloadingClass {

	public void chat(String father,String mother) {
		System.out.println("Yes I will come to home on time");
	}
	
	public void chat(String girlFriend) {
		System.out.println("Yes I will come to meet you today");
	}
	
	public void chat(char bossInit) {
		System.out.println("Yes boss I will attent meeting on time");
	}
	
	
	public static void main(String[] args) {
		
		MethodOverloadingClass methodOverloadingClass = new MethodOverloadingClass();
		
		methodOverloadingClass.chat('B');
		methodOverloadingClass.chat("GF1");
		methodOverloadingClass.chat("F", "M");
	}
}
