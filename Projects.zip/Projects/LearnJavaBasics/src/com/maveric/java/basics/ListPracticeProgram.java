package com.maveric.java.basics;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class ListPracticeProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList numbersArrayList = new ArrayList<>();

		numbersArrayList.add("StringVariable");
		numbersArrayList.add(2356);
		numbersArrayList.add('D');

		numbersArrayList.remove("2356");
		for(Object var1 : numbersArrayList) {
			System.out.println(var1);
		}

		ArrayList<Integer> numbersArrayList1 = new ArrayList<Integer>();

		numbersArrayList1.add(100);
		numbersArrayList1.add(200);
		numbersArrayList1.add(300);
		numbersArrayList1.add(200);
		numbersArrayList1.add(null);
		numbersArrayList1.add(750);
		numbersArrayList1.add(850);

		for(Integer num1 : numbersArrayList1) {
			System.out.println(num1);
		}

		for(int i=0;i<numbersArrayList1.size();i++) {
			System.out.println("Get value "+i+" from array list=>"+numbersArrayList1.get(i));
		}

		System.out.println("Index of "+numbersArrayList1.indexOf(200));

		System.out.println("Last Index of "+numbersArrayList1.lastIndexOf(200));

		numbersArrayList1.remove(null);

		for(int i=0;i<numbersArrayList1.size();i++) {
			System.out.println("Get value "+i+" from array list=>"+numbersArrayList1.get(i));
		}

		numbersArrayList1.remove(1);
		System.out.println();
		for(int i=0;i<numbersArrayList1.size();i++) {
			System.out.println("Get value "+i+" from array list=>"+numbersArrayList1.get(i));
		}

		System.out.println(numbersArrayList1.isEmpty());

		ArrayList<Integer> numbersArrayList2 = new ArrayList<Integer>();

		numbersArrayList2.add(50);
		numbersArrayList2.add(25);

		numbersArrayList1.addAll(numbersArrayList2);

		Iterator<Integer> iterator = numbersArrayList1.iterator();

		while (iterator.hasNext()) {
			System.out.println("Iterator list => "+iterator.next());

		}

		ListIterator<Integer> listiterator = numbersArrayList1.listIterator();
		while (listiterator.hasPrevious()) {
			System.out.println("List Iterator list => "+listiterator.previous());

		}
		
		
		LinkedList<String> colorsLinkedList = new LinkedList<String>();
		
		
		colorsLinkedList.add("Red");
		colorsLinkedList.add("Blue");
		colorsLinkedList.add(null);
		colorsLinkedList.add("Blue");
		
		for (Iterator iterator2 = colorsLinkedList.iterator(); iterator2.hasNext();) {
			String string = (String) iterator2.next();
			
			System.out.println(string);
		}
		
		System.out.println(colorsLinkedList.getFirst());
		System.out.println(colorsLinkedList.removeLast());
		
		for (Iterator iterator2 = colorsLinkedList.iterator(); iterator2.hasNext();) {
			String string = (String) iterator2.next();
			
			System.out.println(string);
		}
		

	}
}