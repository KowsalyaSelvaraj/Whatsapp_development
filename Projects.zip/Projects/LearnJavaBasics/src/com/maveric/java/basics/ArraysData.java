package com.maveric.java.basics;

import java.util.Arrays;

public class ArraysData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//how to initialize the array
		//0 to 9 color[0] = 1, color[2] = 3
		//1st array
		int[] square = new int[10];

		//2nd array 
		String[] colorString = new String[12];

		//3rd array
		String[] colorStrings1 = {"Red","Blue"};


		System.out.println("1st array "+square.length);
		System.out.println("2nd array "+colorString.length);
		System.out.println("3rd array "+colorStrings1.length);

		//How to assign the value
		square[0] = 1;
		square[1] = 4;
		square[2] = 9;
		int num = 1;

		System.out.println(square[0] +" - "+square[1]+" - "+square[2] + " - "+square[3]);
		System.out.println(square[0] +square[1]+square[2]);

		for(int i=0; i<square.length;i++) {
			square[i] = num*num;  // Square[0] = 1*1;  

			System.out.print(num+" ");
			num++;
		}
		System.out.println();

		//to iterate an array using for loop
		for(int i=0; i<square.length;i++) {
			System.out.print(square[i]+" ");
		}
		System.out.println("reverse order ");
		
		for(int i=square.length-1; i>=0;i--) {
			System.out.print(square[i]+" ");
		}

		//for each loop
		for(int numberFromArray : square) {
			System.out.println(numberFromArray);
		}

		//cube value array.- HW
		//			0				1			2					3
		String[] juiceStrings = {"Mango Shake","Apple Shake", "Banana Milk Shake", "Fig Shake"};

		//Sort method
		Arrays.sort(juiceStrings);

		for(String singleJuiceString : juiceStrings) {
			System.out.println(singleJuiceString);
		}

		//float binary search
		float[] amountGivenToSon = {10.50f, 20.30f, 50.60f,5.50f,06.80f};
		float[] amountGivenToDaughter = {10.50f, 20.30f, 50.60f,5.50f,06.80f};

		Arrays.sort(amountGivenToSon);

		for(float amount : amountGivenToSon) {
			System.out.println(amount);
		}
		int returnValue =  Arrays.binarySearch(amountGivenToSon, 50.60f);

		System.out.println(returnValue);

		
	}

}
