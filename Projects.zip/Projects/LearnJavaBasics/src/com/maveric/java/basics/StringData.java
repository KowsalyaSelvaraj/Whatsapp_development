package com.maveric.java.basics;

public class StringData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//2 type declaration
		String nameString = "Gopal";

		String nameString2 = new String("Family");
		
		System.out.println(nameString+" and "+nameString2);
		
		
		//Split function	0   1  2  3
		String nameString3 = "India,is,my,country";
		
		String[] stringArray = 	nameString3.split(",");
		
		int countOfArray = stringArray.length;
		
		for(int i=0;i<countOfArray;i++) {
			System.out.println(i+"=> "+stringArray[i]);
		}
		
		String nameString4 = "I love India";
		
		System.out.println("Length of the string => "+nameString4.length());
		
		System.out.println("Character at 1 => "+nameString4.charAt(0));
		
		System.out.println("Character at last => "+nameString4.charAt(nameString4.length()-1));
		
		System.out.println("Contains =>"+nameString4.contains("India"));
		
		System.out.println("Contains not =>"+nameString4.contains("Brother"));
		
		String nameString5 = " the string is displayed in Ui ";
		System.out.println("remove space =>"+nameString5.trim());
		
	}

}
