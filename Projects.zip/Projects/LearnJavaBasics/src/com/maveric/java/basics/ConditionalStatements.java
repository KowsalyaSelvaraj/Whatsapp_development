package com.maveric.java.basics;

import java.util.Scanner;


public class ConditionalStatements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String	vegetableAvailable = "ladies finger";
		String	vegetableBasket = "";

		if(vegetableAvailable.equalsIgnoreCase("Drumstick")) {
			vegetableBasket = "Drumstick";
		}else if(vegetableAvailable.equals("Ladies Finger")){
			vegetableBasket = "Ladies Finger";
		}else {
			vegetableBasket = "Onion";
		}

		//System.out.println(vegetableBasket);

		Scanner scanner = new Scanner(System.in);

		System.out.println("Please give ur vegetable name");
		String vegetableName = scanner.nextLine();
		vegetableBasket = "";

		switch(vegetableName) {

		case "Drumstick":
			vegetableBasket = "Drumstick";
			break;

		case "Raddish":
			vegetableBasket = "Raddish";
			System.out.println("Inside raddish");
			break;

		case "Ladies Finder":
			vegetableBasket = "Ladies Finger";
			System.out.println("Inside ladies finger");
			break;

		default:
			vegetableBasket = "Onion";
			System.out.println("Inside onion");
			break;
		}

		System.out.println(vegetableBasket);

	}




}
