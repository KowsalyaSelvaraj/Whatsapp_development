package com.maveric.java.basics;

public class EncapsulationPractise {
	
	private String m1;
	private String m2;
	
	
	public String getM1() {
		return m1;
	}
	public void setM1(String m1) {
		this.m1 = m1;
	}
	public String getM2() {
		return m2;
	}
	public void setM2(String m2) {
		this.m2 = m2;
	}
	
}


class hello{
	
	
}
