package com.maveric.java.basics;

public class Operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		float a = 5.50000f;
		float b;

		b=a; 
		System.out.println(b);

		//b=b+a;
		b+=a;
		System.out.println(b);

		long num1 = 250L;
		long num2 = 50L;

		num2*=num1; 
		System.out.println(num2);

		float value1 = 200f;
		float value2 = 40f;

		value2/=value1;
		//value2 = value2/value1;
		System.out.println(value2);

		//		num2/=num1;
		//		
		//		System.out.println(num2);

		Operators operators = new Operators();
		operators.UnaryOerator();

	}

	public  void  relationalOperator() {

		int data1 = 10;
		int data2 = 15;

		System.out.println("data1==data2 "+(data1<data2));

	}

	public  void logicalOperator() {

		int val1 = 10;
		int val2 = 15;

		System.out.println("Value => "+(val1<=val2));
		System.out.println("Value => "+(val1<val2));

		if((val1<=val2) && (val1<val2)) {
			System.out.println("both condition passes");	
		}

		if((val1==val2) || (val1>val2)) {
			System.out.println("either one shld be pass");	
		}
		
	}
	
	public  void UnaryOerator() {

		int u1 = 10;
		int u2 = 15;

		System.out.println("unary operator");
		System.out.println(u1++);
		System.out.println(u1);
		
		System.out.println(++u2);
		System.out.println(++u2);
		
		 u1 = 10;
		 u2 = 15;
		System.out.println(u1--);
		System.out.println(u1);
		
		System.out.println(--u2);
		System.out.println(--u2);
		
		
		for(int i=0;i<5;i++) {
			System.out.println("value of i++ "+i);
		}
		
		for(int i=5;i>=0;i--){
			System.out.println("value of i-- "+i);
		}
	
		System.out.println("decrement by 2 ");
		for(int i=10;i>=0;i-=2)//i=i-2 {
			System.out.println("value of decrement by 2 "+i);
		}
		
	}


