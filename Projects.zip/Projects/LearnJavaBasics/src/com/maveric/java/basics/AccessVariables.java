package com.maveric.java.basics;

public class AccessVariables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EncapPractise encapPractise = new EncapPractise();
		
		encapPractise.setBottleCost(10);
		
		System.out.println(encapPractise.getBottleCost());
		
		encapPractise.setBottleNameString("Coke");
		System.out.println(encapPractise.getBottleNameString());
		
	}

}
