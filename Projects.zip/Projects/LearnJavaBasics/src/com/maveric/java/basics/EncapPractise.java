package com.maveric.java.basics;

public class EncapPractise {

	
	//private variables
	
	private String bottleNameString;
	
	private int bottleCost ;
	
	public int bottleBuy ;

	public String getBottleNameString() {
		return bottleNameString;
	}

	public void setBottleNameString(String bottleNameString) {
		this.bottleNameString = bottleNameString;
	}

	public int getBottleCost() {
		return bottleCost;
	}

	public void setBottleCost(int bottleCost) {
		this.bottleCost = bottleCost;
	}
}


