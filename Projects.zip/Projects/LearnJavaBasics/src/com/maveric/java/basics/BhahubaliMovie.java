package com.maveric.java.basics;

public class BhahubaliMovie {

	public static void main(String[] args) {

		String leadRoleString = "Prabhas";
		String villanString = "Rana";
		String femaleLeadRoleString ="Anushka"; 

		int totalCollection = 907000;
		long totalCollection1 = 907000000000L;

		float ticketRateInInox = 170.5f; // decimal
		double ticketRateInEscape = 99.5;

		char movieCertificate = '1';

		boolean isTheMovieAwesome = true;

		boolean isTheMovieNotGood = false;

		BhahubaliMovie bhahubaliMovie = new BhahubaliMovie();

		bhahubaliMovie.printMovieName();

		bhahubaliMovie.printCastandCrewName(femaleLeadRoleString, femaleLeadRoleString);

		String takeDecisionString = bhahubaliMovie.canIGoToTheMovie(ticketRateInInox);
				
		System.out.println(takeDecisionString);
		
	}

	public void printMovieName() {
		System.out.println("Bhahubali");
	}

	public void printCastandCrewName(String leadRole,String leadFemaleRole) {
		System.out.println(leadRole+" and "+leadFemaleRole);
	}

	public String canIGoToTheMovie(float ticketRate) {

		String goToMovieString = "";
		System.out.println("check statement "+(ticketRate<150.50f));
		
		if(ticketRate<150.50f) {
			goToMovieString = "Yes You can go";
		}else {
			goToMovieString = "No you can't go";
		}
		return goToMovieString;
	}

	

}
