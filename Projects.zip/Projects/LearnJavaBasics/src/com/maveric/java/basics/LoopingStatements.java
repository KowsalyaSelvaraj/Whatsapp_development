package com.maveric.java.basics;

public class LoopingStatements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i=1; i<=20;i++) {
			System.out.println("I will do my homework "+i);
		}
		
		System.out.println("Assignment completed");
		
		boolean didYouFinishHomework = true;
		
		while(didYouFinishHomework) {
			System.out.println("Ok please go inside the class");
			break;
		}
		
		int numberOfTimesAssignment = 0;
		
		while(numberOfTimesAssignment<=20) {
			System.out.println("assignment count "+numberOfTimesAssignment);
			numberOfTimesAssignment++;
		}
		
		boolean areYouOk = false;
		do {
			System.out.println("you are inside the loop");
		}while(areYouOk);
		
	}

}
