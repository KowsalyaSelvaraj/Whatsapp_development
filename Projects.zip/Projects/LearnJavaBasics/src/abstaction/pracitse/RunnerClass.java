package abstaction.pracitse;

import multilevel.inheritance.Grandparent;

public class RunnerClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Me iaMe  = new Me();
		
		//MyGrandparent grandparent = new MyGrandparent();
		
		//MyFather father = new MyFather();
		iaMe.completed10th();
		iaMe.completed12th();
		iaMe.completsEngineering();
	}

}
