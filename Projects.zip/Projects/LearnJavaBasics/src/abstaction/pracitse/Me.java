package abstaction.pracitse;

public class Me extends MyFather{

	@Override
	public void completsEngineering() {
		// TODO Auto-generated method stub
		
	}

	
	
}
