package abstaction.pracitse;

public abstract class MyFather extends MyGrandparent{

	
	
	public  void completed12th() {

		System.out.println("Completed 12th");
	}
	
	public abstract  void completsEngineering();
}
