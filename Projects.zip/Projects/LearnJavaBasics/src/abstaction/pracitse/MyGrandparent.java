package abstaction.pracitse;

public abstract  class MyGrandparent {

	//can't create a object to a this class as it has abstract methods
	
	public void completed10th() {
	
		System.out.println("Completed 10th");
	}
	
	public abstract void completed12th();
	
	public abstract void completsEngineering();
	
}
