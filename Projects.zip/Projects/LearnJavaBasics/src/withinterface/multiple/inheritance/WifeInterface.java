package withinterface.multiple.inheritance;

public interface WifeInterface {

	public void cookAndProvideFoodWithCare();
	public void pleaseCookformealso();
}

