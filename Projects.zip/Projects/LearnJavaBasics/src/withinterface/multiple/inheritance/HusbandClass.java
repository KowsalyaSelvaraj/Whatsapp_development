package withinterface.multiple.inheritance;

public class HusbandClass implements MotherInteface,WifeInterface
{

	@Override
	public void cookAndProvideFoodWithCare() {
		
		System.out.println("I will cook food by myself");
	}

	@Override
	public void pleaseCookformealso() {
		// TODO Auto-generated method stub
		
	}

	
	
}
