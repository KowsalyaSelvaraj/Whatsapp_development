package withinterface.multiple.inheritance;

public interface MotherInteface {


	public void cookAndProvideFoodWithCare();
	
	//accepts default and static methods
	
}
