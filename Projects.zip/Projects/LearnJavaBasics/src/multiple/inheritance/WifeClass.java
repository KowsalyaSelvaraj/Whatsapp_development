package multiple.inheritance;

public class WifeClass {

	public void cookAndProvideFoodWithCare() {
		System.out.println("Providing Mutton Biriyani");
	}
}
