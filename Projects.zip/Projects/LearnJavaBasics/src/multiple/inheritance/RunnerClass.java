package multiple.inheritance;

public class RunnerClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	HusbandClass husbandClass = new HusbandClass();
		
		//husbandClass.cookAndProvideFoodWithCare();
		//husbandClass.cookAndProvideFoodWithLove();
	}

}
