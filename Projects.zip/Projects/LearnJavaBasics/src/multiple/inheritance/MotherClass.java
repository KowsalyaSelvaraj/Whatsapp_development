package multiple.inheritance;

public class MotherClass {


	public void cookAndProvideFoodWithCare() {
		System.out.println("Providing Chicken Biriyani");
	}
	
}
