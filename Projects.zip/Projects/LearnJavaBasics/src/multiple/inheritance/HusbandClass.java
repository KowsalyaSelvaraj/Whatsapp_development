//package multiple.inheritance;
//
//public class HusbandClass extends MotherClass, WifeClass
//{
//
//	@Override
//	public void cookAndProvideFoodWithCare() {
//		
//		super.cookAndProvideFoodWithCare();
//	}
//	
//	
//	
//}
