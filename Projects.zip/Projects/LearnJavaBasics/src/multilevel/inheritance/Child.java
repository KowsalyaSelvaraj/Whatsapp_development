package multilevel.inheritance;

public class Child extends Parent{

	String childNameString = "";
	
	public void myparentDetails() {
		System.out.println("My father name is  "+fatherNameString);
		System.out.println("My mother name is  "+motherNameString);
	}
	
	public void provideCollegeEducation() {
		System.out.println("My father name is  "+fatherNameString);
		System.out.println("My mother name is  "+motherNameString);
		System.out.println("I will join viscom only not engineering");
	}
	
	
}
