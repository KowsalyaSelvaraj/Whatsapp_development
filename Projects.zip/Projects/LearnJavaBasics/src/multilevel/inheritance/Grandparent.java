package multilevel.inheritance;

public class Grandparent {

	String grandFatherString = "Rama";
	
	public void providePropertyinECR() {
		
		System.out.println("Buy 10 arces land in ECR");
	}
}
