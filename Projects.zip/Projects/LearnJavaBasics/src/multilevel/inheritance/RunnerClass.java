package multilevel.inheritance;

public class RunnerClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Child child = new Child();
		
		child.provideFood();
		child.provideSchoolEducation();
		child.provideCollegeEducation();
		
		child.providePropertyinECR();
		
	//	child.m
		
		Parent parent = new Parent();
		parent.providePropertyinECR();
	}

}
