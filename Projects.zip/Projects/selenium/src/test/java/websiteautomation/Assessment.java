package websiteautomation;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
public class Assessment {

	static int i=0;
	@Test
	public void handlingAlerts() throws AWTException, IOException, InterruptedException {
		System.setProperty("webdriver.edge.driver", "C:\\Users\\kowsalyas\\Drivers\\msedgedriver.exe");


		WebDriver driver = new EdgeDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		driver.get("https://demoqa.com/automation-practice-form");
		WebElement firstName = driver.findElement(By.id("firstName"));
		firstName.sendKeys("Leo");
		WebElement lastName = driver.findElement(By.id("lastName"));
		lastName.sendKeys("Dass");
		WebElement email = driver.findElement(By.id("userEmail"));
		email.sendKeys("leodass@gmail.com");
		WebElement gender = driver.findElement(By.xpath("//*[@id=\"genterWrapper\"]/div[2]/div[1]/label"));
		gender.click();
		WebElement mobileNumber = driver.findElement(By.id("userNumber"));
		mobileNumber.sendKeys("6379143555");
		WebElement dob = driver.findElement(By.id("dateOfBirthInput"));
		dob.click();
		WebElement yearDropdown = driver.findElement(By.className("react-datepicker__year-select"));
		Select yearSelect = new Select(yearDropdown);
		yearSelect.selectByVisibleText("1974");

		WebElement monthDropdown = driver.findElement(By.className("react-datepicker__month-select"));
		Select monthSelect = new Select(monthDropdown);
		monthSelect.selectByVisibleText("June");
		WebElement date = driver.findElement(By.xpath("//*[@id=\"dateOfBirth\"]/div[2]/div[2]/div/div/div[2]/div[2]/div[4]/div[7]"));
		date.click();
//		WebElement subjectsInput = driver.findElement(By.id("subjectsInput"));
//		subjectsInput.sendKeys("Computer Science");

//		WebElement autoCompleteOption = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("react-select-2-option0")));
//		autoCompleteOption.click();
		WebElement sportsCheckbox = driver.findElement(By.className("custom-control custom-checkbox custom-control-inline"));
		// Adjust the id based on the actual webpage
		sportsCheckbox.click();
		WebElement musicCheckbox = driver.findElement(By.className("custom-control-label")); // Adjust the id based on the
		//actual webpage
		musicCheckbox.click();
	}


	public static void takeScreenshot(WebDriver driver) throws IOException {
		TakesScreenshot scrShot = ((TakesScreenshot)driver);
		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		File DestFile=new File("C:\\Users\\kowsalyas\\Desktop\\NewTab"+i+".png");
		i++;
		//Copy file at destination
		FileUtils.copyFile(SrcFile, DestFile);



	}
}
