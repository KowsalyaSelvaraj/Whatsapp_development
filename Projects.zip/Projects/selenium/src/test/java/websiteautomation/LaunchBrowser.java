package websiteautomation;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;



public class LaunchBrowser {

	@Test(enabled = false)
	public void launchBrowserAndMaxandMinWindow() {

	//	WebDriverManager.firefoxdriver().setup();

		System.setProperty("webdriver.edge.driver", "C:\\Users\\kowsalyas\\Drivers\\msedgedriver.exe");

		WebDriver driver = new EdgeDriver();

		driver.manage().window().maximize();
		
		driver.get("https://demoqa.com/");
		
		driver.manage().window().minimize();
	}
	
	@Test(enabled = true)
	public void launchBrowserAndWaitforIt() throws InterruptedException {

	//	WebDriverManager.firefoxdriver().setup();

		System.setProperty("webdriver.edge.driver", "C:\\Users\\kowsalyas\\Drivers\\msedgedriver.exe");

		WebDriver	driver = new EdgeDriver();

		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		driver.get("https://demoqa.com/");
		driver.manage().window().minimize();
		Thread.sleep(2000);
		
		driver.close();
	}
	
	@Test(enabled = true)
	public void locateElements() throws InterruptedException {

		//	WebDriverManager.firefoxdriver().setup();

			System.setProperty("webdriver.edge.driver", "C:\\Users\\kowsalyas\\Drivers\\msedgedriver.exe");

			WebDriver	driver = new EdgeDriver();

			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
			driver.manage().window().maximize();
			driver.get("https://demoqa.com/automation-practice-form");
			
			//Locators -> ID, NAME, CLass, linked Text, Partial linked text
			driver.findElement(By.id("firstName")).sendKeys("Jaya Shree");
			
			Thread.sleep(5000);
			driver.switchTo().newWindow(WindowType.TAB);
			driver.get("https://demoqa.com/links");
			driver.findElement(By.linkText("Home")).click();
						
			driver.close();
		}
	
	@Test(enabled = false)
	public void locateElementsWithLinks() {

		//	WebDriverManager.firefoxdriver().setup();

			System.setProperty("webdriver.edge.driver", "C:\\Users\\kowsalyas\\Drivers\\msedgedriver.exe");

			WebDriver	driver = new EdgeDriver();

			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

			driver.manage().window().maximize();
			driver.get("https://demoqa.com/automation-practice-form");
			
			//Locators -> ID, NAME, CLass, linked Text, Partial linked text
			driver.findElement(By.id("firstName")).sendKeys("Jaya Shree");
			driver.findElement(By.id("firstName")).sendKeys("Jaya Shree");
			driver.findElement(By.id("firstName")).sendKeys("Jaya Shree");
			
			driver.switchTo().newWindow(WindowType.TAB);
			driver.get("https://demoqa.com/links");
			
			driver.findElement(By.linkText("Home")).click();
			//driver.close();
		}
}
