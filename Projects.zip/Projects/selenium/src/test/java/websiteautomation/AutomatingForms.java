package websiteautomation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AutomatingForms {

	
	@Test
	public void launchBrowser() {

		WebDriverManager.firefoxdriver().setup();

	//	System.setProperty("webdriver.edge.driver", "C:\\Users\\kowsalyas\\Drivers\\msedgedriver.exe");

		WebDriver	driver = new FirefoxDriver();

		driver.get("https://demoqa.com/");
		
		
	}
	
}
