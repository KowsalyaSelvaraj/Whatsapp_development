package applicationcode;

import org.testng.Assert;
import org.testng.annotations.Test;

public class SanityTestClass {
 
	
@Test(dependsOnMethods = "Swimming")
  public void Running() {
	  
	  System.out.println("Method is getting executed 1");
  }
  
  @Test(alwaysRun = true,priority = 999)
  public void Jogging() {
	  
	  System.out.println("Method is getting executed 2 ");
  }
  
  @Test
  public void Swimming() {
	  Assert.assertEquals(false, true);
	  System.out.println("Method is getting executed 3");
  }
  
//  @Test(priority = 3)
//  public void Sleeping() {
//	  
//	  System.out.println("Method is getting executed 4");
//  }
}
