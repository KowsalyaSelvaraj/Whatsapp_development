package applicationcode;

import org.testng.annotations.Test;

public class RegressionTestClass {
 
	
	@Test(priority = -1 )
  public void Running() {
	  
	  System.out.println("Method is getting executed 1");
  }
  
  @Test(enabled = true,priority = 0)
  public void Jogging() {
	  
	  System.out.println("Method is getting executed 2 ");
  }
  
  @Test(priority = 2)
  public void Swimming() {
	  
	  System.out.println("Method is getting executed 3");
  }
  
  @Test(priority = 3)
  public void Sleeping() {
	  
	  System.out.println("Method is getting executed 4");
  }
}
