package tests;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class CheckBusAvailability {

	
	
	@Test(priority = 0)
	public void checkBusInCMBT() {
		
		System.out.println("CMBT would be my 1st preference");
	}
	
	
}
