package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class HomePage extends BasePage{


//	public HomePage() {
//		PageFactory.initElements(driver, this);
//	}

	public HomePage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(BasePage.driver, this);
	}

	@FindBy(id = "src")
	private static WebElement sourceElement;

	@FindBy(xpath = "//*[text()='From']//following::ul/li//text[contains(@class,'MainText')]")
	private static WebElement sourceDropDownElement;

	@FindBy(xpath = "//*[text()='From']//following::ul/li")
	private static List<WebElement> sourceLocations;

	@FindBy(id = "dest")
	private static WebElement destinationElement;

	@FindBy(xpath = "//*[text()='To']//following::ul/li//text[contains(@class,'MainText')]")
	private static WebElement destinationDropDownElement;

	@FindBy(xpath = "//*[text()='To']//following::ul/li")
	private static List<WebElement> destinationLocations;

	@FindBy(className = "labelCalendarContainer")
	private static WebElement calenderElement;

	@FindBy(xpath = "//*[contains(@class,'CalendarHeader')]/div[2]")
	private static WebElement calenderHeaderElement;

	@FindBy(xpath = "//*[contains(@class,'CalendarHeader')]/div[3]")
	private static WebElement calenderHeaderNextButtonElement;

	@FindBy(id = "search_button")
	private static WebElement searchButton;


	//getters and setters
	public static WebElement getSourceElement() {
		return sourceElement;
	}


	public static void setSourceElement(WebElement sourceElement) {
		HomePage.sourceElement = sourceElement;
	}


	public static WebElement getSourceDropDownElement() {
		return sourceDropDownElement;
	}


	public static void setSourceDropDownElement(WebElement sourceDropDownElement) {
		HomePage.sourceDropDownElement = sourceDropDownElement;
	}


	public static List<WebElement> getSourceLocations() {
		return sourceLocations;
	}


	public static void setSourceLocations(List<WebElement> sourceLocations) {
		HomePage.sourceLocations = sourceLocations;
	}


	public static WebElement getDestinationElement() {
		return destinationElement;
	}


	public static void setDestinationElement(WebElement destinationElement) {
		HomePage.destinationElement = destinationElement;
	}


	public static WebElement getDestinationDropDownElement() {
		return destinationDropDownElement;
	}


	public static void setDestinationDropDownElement(WebElement destinationDropDownElement) {
		HomePage.destinationDropDownElement = destinationDropDownElement;
	}


	public static List<WebElement> getDestinationLocations() {
		return destinationLocations;
	}


	public static void setDestinationLocations(List<WebElement> destinationLocations) {
		HomePage.destinationLocations = destinationLocations;
	}


	public static WebElement getCalenderElement() {
		return calenderElement;
	}


	public static void setCalenderElement(WebElement calenderElement) {
		HomePage.calenderElement = calenderElement;
	}


	public static WebElement getCalenderHeaderElement() {
		return calenderHeaderElement;
	}


	public static void setCalenderHeaderElement(WebElement calenderHeaderElement) {
		HomePage.calenderHeaderElement = calenderHeaderElement;
	}


	public static WebElement getCalenderHeaderNextButtonElement() {
		return calenderHeaderNextButtonElement;
	}


	public static void setCalenderHeaderNextButtonElement(WebElement calenderHeaderNextButtonElement) {
		HomePage.calenderHeaderNextButtonElement = calenderHeaderNextButtonElement;
	}


	public static WebElement getSearchButton() {
		return searchButton;
	}


	public static void setSearchButton(WebElement searchButton) {
		HomePage.searchButton = searchButton;
	}


	//Methods
	public void enterSourceLocation(String sourceCity,String sourceLocation) {
		try {
		if(sourceLocation.equals("")) {
			sendDataToField(getSourceElement(),sourceCity);			
		}else {
			sendDataToField(getSourceElement(),sourceLocation);
		}


		waitForVisibilityOfElement( sourceDropDownElement);

		for(WebElement element:getSourceLocations()) {
			System.out.println(element.getText());

			if(sourceCity.isEmpty()) {
				if(element.getText().contains(sourceLocation)) {
					System.out.println(element.getText()+" selected");
					element.click();
					break;
				}
			}else if(sourceLocation.isEmpty()) {
				if(element.getText().contains(sourceCity)) {
					System.out.println(element.getText()+" selected");
					element.click();
					break;
				}
			}else {
				if(element.getText().contains(sourceCity) && element.getText().contains(sourceLocation)) {
					System.out.println(element.getText()+" selected");
					element.click();
					break;
				}
			}
			
			
		}
		}catch (Exception e) {
			
		}
	}

	public void enterDestinationLocation(String destinationCity, String destinationLocation) {
		//destination location
		if(destinationLocation.equals("")) {
			sendDataToField(getDestinationElement(),destinationCity);			
		}else {
			sendDataToField(getDestinationElement(),destinationLocation);
		}
		waitForVisibilityOfElement(getDestinationDropDownElement());
		for(WebElement destination: destinationLocations) {
			System.out.println(destination.getText());

			if(destinationCity.isEmpty()) {
				if(destination.getText().contains(destinationLocation)) {
					System.out.println(destination.getText()+" selected");
					destination.click();
					break;
				}
			}else if(destinationLocation.isEmpty()) {
				if(destination.getText().contains(destinationCity)) {
					System.out.println(destination.getText()+" selected");
					destination.click();
					break;
				}
			}else {
				if(destination.getText().contains(destinationCity) && destination.getText().contains(destinationLocation)) {
					System.out.println(destination.getText()+" selected");
					destination.click();
					break;
				}
			}
		}

	}


	public void enterTravelDate(String travelDate) {
		//select date

		driver.findElement(By.className("labelCalendarContainer")).click();
		waitAndClickElement(getCalenderElement());
		
		String date = travelDate.split("-")[0];
		String monthString = travelDate.split("-")[1];
		String yearString = travelDate.split("-")[2];
		boolean conditionMatched = true;
		//header date and year
		String monthAndYear =  getCalenderHeaderElement().getText();
		System.out.println(monthAndYear);
		System.out.println("Month "+monthString);
		System.out.println("Year "+yearString);
		while (conditionMatched) {
			if(monthAndYear.contains(monthString) && monthAndYear.contains(yearString)) {
				driver.findElement(By.xpath("//span[contains(@class,'CalendarDaysSpan') and   text()='"+date+"']")).click();
				conditionMatched = false;
			}else {
				getCalenderHeaderNextButtonElement().click();
				monthAndYear =  getCalenderHeaderElement().getText();
				System.out.println(monthAndYear);
			}
		}

	}


	public void seachForBuses() {
		//search busses
		waitAndClickElement(getSearchButton());
		
	}

}
