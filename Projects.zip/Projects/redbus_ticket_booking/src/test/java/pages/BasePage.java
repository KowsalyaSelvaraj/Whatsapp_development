package pages;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import tests.BaseTest;

public class BasePage {

	public static WebDriver driver;
    public static WebDriverWait wait;
    
    public BasePage(WebDriver driver) {
    	
        this.driver = driver;
        PageFactory.initElements(this.driver, this);
        wait = new WebDriverWait(this.driver, Duration.ofSeconds(30));
    }
    
    public static void scrollIntoViewElement(WebDriver driver,WebElement element) {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

		jsExecutor.executeScript("arguments[0].scrollIntoView(true)",element);

	}

	public static void waitAndClickElement(WebElement element) {

		wait.until(ExpectedConditions.elementToBeClickable(element));

		element.click();
	}

	public static void waitForVisibilityOfElement(WebElement element) {

		wait.until(ExpectedConditions.visibilityOf(element));

	}
	
	public void highlightElement(WebDriver driver, WebElement element) {
		JavascriptExecutor jsExecutor = (JavascriptExecutor)  driver;

		jsExecutor.executeScript("arguments[0].style.border='3px solid red'", element);

	}

	public void unhighlightElement(WebDriver driver, WebElement element) {
		JavascriptExecutor jsExecutor = (JavascriptExecutor)  driver;

		jsExecutor.executeScript("arguments[0].style.border='0px'", element);

	}

	public static void sendDataToField(WebElement element,String value) {
		wait.until(ExpectedConditions.visibilityOf(element));

		element.sendKeys(value);
	}
    
    
}
