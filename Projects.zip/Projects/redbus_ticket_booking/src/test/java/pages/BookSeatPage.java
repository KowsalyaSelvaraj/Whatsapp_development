package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.fasterxml.jackson.annotation.JacksonInject.Value;

import utils.ExtentReportsGenerator;

public class BookSeatPage extends BasePage{

	public BookSeatPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(BasePage.driver, this);
	}

	@FindBy(id = "src")
	private static WebElement sourceElement;

	@FindBy(xpath = "//*[text()='Modify']")
	private static WebElement modifyElement;

	@FindBy(xpath = "//span[contains(text(),'Ok, got it')]")
	private static WebElement popUpImportantTipElement;

	@FindBy(xpath = "//i[@class='icon icon-close']")
	private static WebElement closePopUpIconElement;

	@FindBy(xpath = "//a[text()='Ratings']")
	private static WebElement orderByRatingElement;

	@FindBy(xpath = "//div[contains(@class,'new-msg')]")
	private static List<WebElement> resultsElements;

	@FindBy(xpath = "//span[contains(@class,'found')]")
	private static WebElement totalNoOfBusesFoundElement;

	@FindBy(xpath = "//div[contains(@class,'two')]/div[contains(@class,'travels')]")
	private static WebElement topBusNameElement;

	@FindBy(xpath = "//div[@class='selectBpDpHeading']")
	private static WebElement selectBpDp;

	@FindBy(xpath = "//div[contains(@class,'button view-seats')]")
	private static WebElement viewSeatElement;

	@FindBy(xpath = "//ul[@data-value='bp']//div[contains(@class,'bpDpAddr-css')]//preceding-sibling::div/div")
	private static WebElement boardingPointElement;

	@FindBy(xpath = "//ul[@data-value='bp']//div[contains(@class,'bpDpAddr-css')]")
	private static List<WebElement> boardingPointsElements;

	@FindBy(xpath = "//span[text()='DROPPING POINT']")
	private static WebElement dropingPointHeaderElement;

	@FindBy(xpath = "//ul[@data-value='dp']//div[contains(@class,'bpDpAddr-css')]//preceding-sibling::div/div")
	private static WebElement dropingPointElement;

	@FindBy(xpath = "//ul[@data-value='dp']//div[contains(@class,'bpDpAddr-css')]")
	private static List<WebElement> dropingPointsElements;

	@FindBy(xpath = "//button[text()='Proceed to book']")
	private static WebElement proceedBookingButtonElement;

	@FindBy(xpath = "//span[@class='bpdp-lb']")
	private static WebElement boardingAndDropingTextElement;

	@FindBy(xpath = "//button[text()='CLEAR ALL FILTERS']")
	private static WebElement clearAllFiltersElement;

	//getters and setters
	public static WebElement getSourceElement() {
		return sourceElement;
	}


	public static void setSourceElement(WebElement sourceElement) {
		BookSeatPage.sourceElement = sourceElement;
	}


	public static WebElement getModifyElement() {
		return modifyElement;
	}


	public static void setModifyElement(WebElement modifyElement) {
		BookSeatPage.modifyElement = modifyElement;
	}


	public static WebElement getPopUpImportantTipElement() {
		return popUpImportantTipElement;
	}


	public static void setPopUpImportantTipElement(WebElement popUpImportantTipElement) {
		BookSeatPage.popUpImportantTipElement = popUpImportantTipElement;
	}


	public static WebElement getClosePopUpIconElement() {
		return closePopUpIconElement;
	}


	public static void setClosePopUpIconElement(WebElement closePopUpIconElement) {
		BookSeatPage.closePopUpIconElement = closePopUpIconElement;
	}


	public static WebElement getOrderByRatingElement() {
		return orderByRatingElement;
	}


	public static void setOrderByRatingElement(WebElement orderByRatingElement) {
		BookSeatPage.orderByRatingElement = orderByRatingElement;
	}


	public static List<WebElement> getResultsElements() {
		return resultsElements;
	}


	public static void setResultsElements(List<WebElement> resultsElements) {
		BookSeatPage.resultsElements = resultsElements;
	}


	public static WebElement getTotalNoOfBusesFoundElement() {
		return totalNoOfBusesFoundElement;
	}


	public static void setTotalNoOfBusesFoundElement(WebElement totalNoOfBusesFoundElement) {
		BookSeatPage.totalNoOfBusesFoundElement = totalNoOfBusesFoundElement;
	}


	public static WebElement getTopBusNameElement() {
		return topBusNameElement;
	}


	public static void setTopBusNameElement(WebElement topBusNameElement) {
		BookSeatPage.topBusNameElement = topBusNameElement;
	}


	public static WebElement getSelectBpDp() {
		return selectBpDp;
	}


	public static void setSelectBpDp(WebElement selectBpDp) {
		BookSeatPage.selectBpDp = selectBpDp;
	}


	public static WebElement getViewSeatElement() {
		return viewSeatElement;
	}


	public static void setViewSeatElement(WebElement viewSeatElement) {
		BookSeatPage.viewSeatElement = viewSeatElement;
	}


	public static WebElement getBoardingPointElement() {
		return boardingPointElement;
	}


	public static void setBoardingPointElement(WebElement boardingPointElement) {
		BookSeatPage.boardingPointElement = boardingPointElement;
	}


	public static List<WebElement> getBoardingPointsElements() {
		return boardingPointsElements;
	}


	public static void setBoardingPointsElements(List<WebElement> boardingPointsElements) {
		BookSeatPage.boardingPointsElements = boardingPointsElements;
	}


	public static WebElement getDropingPointHeaderElement() {
		return dropingPointHeaderElement;
	}


	public static void setDropingPointHeaderElement(WebElement dropingPointHeaderElement) {
		BookSeatPage.dropingPointHeaderElement = dropingPointHeaderElement;
	}


	public static WebElement getDropingPointElement() {
		return dropingPointElement;
	}


	public static void setDropingPointElement(WebElement dropingPointElement) {
		BookSeatPage.dropingPointElement = dropingPointElement;
	}


	public static List<WebElement> getDropingPointsElements() {
		return dropingPointsElements;
	}


	public static void setDropingPointsElements(List<WebElement> dropingPointsElements) {
		BookSeatPage.dropingPointsElements = dropingPointsElements;
	}


	public static WebElement getProceedBookingButtonElement() {
		return proceedBookingButtonElement;
	}


	public static void setProceedBookingButtonElement(WebElement proceedBookingButtonElement) {
		BookSeatPage.proceedBookingButtonElement = proceedBookingButtonElement;
	}


	public static WebElement getBoardingAndDropingTextElement() {
		return boardingAndDropingTextElement;
	}


	public static void setBoardingAndDropingTextElement(WebElement boardingAndDropingTextElement) {
		BookSeatPage.boardingAndDropingTextElement = boardingAndDropingTextElement;
	}


	public static WebElement getClearAllFiltersElement() {
		return clearAllFiltersElement;
	}


	public static void setClearAllFiltersElement(WebElement clearAllFiltersElement) {
		BookSeatPage.clearAllFiltersElement = clearAllFiltersElement;
	}

	//methods 
	public void acceptNotifications() throws InterruptedException {

		//Important Tip 
		waitForVisibilityOfElement(getModifyElement());
		waitForVisibilityOfElement(getPopUpImportantTipElement());

		Thread.sleep(6000);
		scrollIntoViewElement(driver, getPopUpImportantTipElement());
		waitAndClickElement( getPopUpImportantTipElement());

		try {
			if(driver.findElement(By.xpath("//i[@class='icon icon-close']")).isDisplayed()) {
				waitAndClickElement(driver.findElement(By.xpath("//i[@class='icon icon-close']")));
			}
		}catch (Exception e) {
			System.out.println("No Pop up displayed");
		}
	}

	public void filterByDepartureTime(String departureTime) {
		WebElement departureTimeElement = driver.findElement(By.xpath("//*[text()='DEPARTURE TIME']//following::label[contains(@title,'"+departureTime+"')][1]"));
		scrollIntoViewElement(driver, departureTimeElement);
		departureTimeElement.click();
	}


	public void filterByBusType(String typeOfBus) {
		WebElement busTypeElement = driver.findElement(By.xpath("//*[text()='BUS TYPES']//following::label[contains(@class,'checkbox') and contains(@for,'"+typeOfBus+"')]"));
		scrollIntoViewElement(driver, busTypeElement);
		busTypeElement.click();
	}


	public void sortByRatings() {	
		scrollIntoViewElement(driver, getOrderByRatingElement());
		waitAndClickElement(getOrderByRatingElement());
	}

	public void validateBusCount(ExtentTest test) {

		System.out.println("Total Number of Buses Found "+getTotalNoOfBusesFoundElement().getText());
		test.pass("Total Number of buses found is "+getTotalNoOfBusesFoundElement().getText());
		for(WebElement resultMessage: getResultsElements()) {
			System.out.println(resultMessage.getText());
			if(resultMessage.getText().contains(" 0 ")) {
				System.out.println("No Buses Found for the filter criteria"+resultMessage.getText().split("from")[1]);
				ExtentReportsGenerator.addResult(test,"Pass","NIL buses found for search criteria"+resultMessage.getText().split("from")[1]);
				
			}else {
				System.out.println("No of Buses for filter criteria is "+resultMessage.getText().split(" ")[1]);
				ExtentReportsGenerator.addResult(test,"Pass","Number of busses found for search criteria "+resultMessage.getText().split("from")[1]+ " is "+resultMessage.getText().split(" ")[1]);
			}
		}
		//Bus details on top
		System.out.println("Top Rated Bus name "+getTopBusNameElement().getText());
		//scrollIntoViewElement(driver, getTopBusNameElement());

		highlightElement(driver,getTopBusNameElement());
		ExtentReportsGenerator.addResult(test,"Pass","Top Rated Bus is  "+getTopBusNameElement().getText());
		///test.pass("Top Rated Bus is  "+getTopBusNameElement().getText());
		unhighlightElement(driver,getTopBusNameElement());
	}


	


	public void viewAndBookSeat(String deckType) throws InterruptedException {

		waitAndClickElement(getViewSeatElement());
		Thread.sleep(2000);
		closePopUp();
		Thread.sleep(4000);
		//book seat
		
		selectSeatFromDeck(driver,"lower");
	}


	public void closePopUp() {
		try {
			
			if(driver.findElement(By.xpath("//i[contains(@class,'closepopupbtn')]")).isDisplayed()) {
				waitAndClickElement(driver.findElement(By.xpath("//i[contains(@class,'closepopupbtn')]")));
				driver.findElement(By.xpath("//i[contains(@class,'closepopupbtn')]")).click();
			}
		}catch (Exception e) {
			System.out.println("NO additional popup displayed");
		}

	}

	public void enterFromAndToPlaces(String sourceLocation, String destinationLocation) {
		scrollIntoViewElement(driver, getSelectBpDp());
		
		//select source location
		if(!sourceLocation.equalsIgnoreCase("")) {
			for(WebElement boardingElement : getBoardingPointsElements()) {

				if(boardingElement.getText().contains(sourceLocation)) {
					waitAndClickElement(boardingElement);
					break;
				}
			}	
		}else {
			waitAndClickElement(getBoardingPointElement());
		}

		//select dropping point in header
		waitAndClickElement(getDropingPointHeaderElement());

		if(!destinationLocation.equalsIgnoreCase("")) {
			for(WebElement dropingElement : getDropingPointsElements()) {
				if(dropingElement.getText().contains(destinationLocation)) {
					waitAndClickElement(dropingElement);
					break;
				}
			}	
		}else {
			waitAndClickElement(getDropingPointElement());
		}

		scrollIntoViewElement(driver, getBoardingAndDropingTextElement());
		waitAndClickElement(getProceedBookingButtonElement());
	}


	public void clearFilter() {
		waitAndClickElement(getClearAllFiltersElement());

	}

	public void selectSeatFromDeck(WebDriver driver, String deckType) {

		scrollIntoViewElement(driver, driver.findElement(By.xpath("//h3[contains(text(),'Seat Price')]")));
		WebElement canvasElement = driver.findElement(By.xpath("//canvas[@data-type='"+deckType+"']"));
		waitForVisibilityOfElement(canvasElement);
		highlightElement(driver, canvasElement);
		Actions actions = new Actions(driver);
		int canvas_X =	canvasElement.getSize().getWidth();
		int canvas_Y = canvasElement.getSize().getHeight();

		System.out.println(canvas_X+" X "+canvas_Y+" Y");
		//actions.moveToElement(canvasElement, canvas_X, canvas_Y).build().perform();

		String seatSelected = "No";

//		for(int i =0;i<canvas_X;i=i+5) {
//			for(int j=0;j<canvas_Y;j++) {
//				actions.moveToElement(canvasElement, i, j).build().perform();
//				canvasElement = driver.findElement(By.xpath("//canvas[@data-type='"+deckType+"']"));
//				System.out.println(canvasElement.getAttribute("class")+" is pointer at points "+i+" =>"+j);
//				if(canvasElement.getAttribute("class").equalsIgnoreCase("pointer")) {
//					actions.click().build().perform();
//					seatSelected = "Yes";
//					break;
//				}
//			}
//
//			if(seatSelected.equalsIgnoreCase("Yes")) {
//				break;
//			}
//		}
		
		int value_X = canvas_X/2;
		int value_Y = canvas_Y/2;
	
		for(int i =0;i<canvas_X/2;i=i+5) {
			for(int j=0;j<canvas_Y/2;j=j+5) {
				actions.moveToElement(canvasElement, i, j).build().perform();
				canvasElement = driver.findElement(By.xpath("//canvas[@data-type='"+deckType+"']"));
			//	System.out.println(canvasElement.getAttribute("class")+" is pointer at points "+i+" =>"+j);
				
				if(canvasElement.getAttribute("class").equalsIgnoreCase("pointer")) {
					actions.click().build().perform();
					seatSelected = "Yes";
					break;
				}
				
				actions.moveToElement(canvasElement, i+value_X, j).build().perform();
				canvasElement = driver.findElement(By.xpath("//canvas[@data-type='"+deckType+"']"));
				//System.out.println(canvasElement.getAttribute("class")+" is pointer at points "+(i+value_X)+" =>"+j);
				if(canvasElement.getAttribute("class").equalsIgnoreCase("pointer")) {
					actions.click().build().perform();
					seatSelected = "Yes";
					break;
				}
				
				actions.moveToElement(canvasElement, i, j+value_Y).build().perform();
				canvasElement = driver.findElement(By.xpath("//canvas[@data-type='"+deckType+"']"));
			//	System.out.println(canvasElement.getAttribute("class")+" is pointer at points "+i+" =>"+(j+value_Y));
				if(canvasElement.getAttribute("class").equalsIgnoreCase("pointer")) {
					actions.click().build().perform();
					seatSelected = "Yes";
					break;
				}
				
				actions.moveToElement(canvasElement, i+value_X, j+value_Y).build().perform();
				canvasElement = driver.findElement(By.xpath("//canvas[@data-type='"+deckType+"']"));
			//	System.out.println(canvasElement.getAttribute("class")+" is pointer at points "+(i+value_X)+" =>"+(j+value_Y));
				if(canvasElement.getAttribute("class").equalsIgnoreCase("pointer")) {
					actions.click().build().perform();
					seatSelected = "Yes";
					break;
				}
			}

			if(seatSelected.equalsIgnoreCase("Yes")) {
				break;
			}
		}
		
		unhighlightElement(driver, canvasElement);
	}



}
