package package1;

public class ClassForExecution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Inside java project");
	}

}
