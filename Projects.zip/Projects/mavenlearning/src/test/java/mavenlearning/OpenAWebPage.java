package mavenlearning;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

public class OpenAWebPage {

	@Test
	public void launchBrowser() {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.edge.driver", "C:\\Users\\kowsalyas\\Drivers\\msedgedriver.exe");

		System.out.println("In side main class");
		WebDriver driver = new EdgeDriver();

		driver.manage().window().maximize();

		driver.get("https://demoqa.com/");

		driver.manage().window().minimize();
	}

}
