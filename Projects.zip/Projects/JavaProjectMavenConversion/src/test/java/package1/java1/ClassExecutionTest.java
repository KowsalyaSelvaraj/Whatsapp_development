package package1.java1;

import org.testng.annotations.Test;

public class ClassExecutionTest {

	@Test
	public void mavenmethod() {
		// TODO Auto-generated method stub
		System.out.println("Java project to maven");
	}

}
