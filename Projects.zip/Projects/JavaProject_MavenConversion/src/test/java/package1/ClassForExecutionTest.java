package package1;

public class ClassForExecutionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In Converted Maven Project");
	}

}
