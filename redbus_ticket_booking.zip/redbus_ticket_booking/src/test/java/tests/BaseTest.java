package tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;

import io.github.bonigarcia.wdm.WebDriverManager;
import pages.BookSeatPage;
import pages.HomePage;
import pages.PassengerDetailsPage;
import utils.ExtentReportsGenerator;

public class BaseTest {

	public static String baseURL;
	public static String sourceLocation;
	public static String sourceCity;

	public static String destinationLocation;
	public static String destinationCity;
	public static String travelDate;

	public static String departureTime;
	public static String typeOfBus;

	public static String emailId;
	public static String contactNo;

	public static String deckType;
	public static String testcaseId;
	public static String testDescription;
	public WebDriver driver;

	public HomePage homePage;
	public BookSeatPage bookSeatPage;
	public PassengerDetailsPage passengerDetailsPage;

	public ExtentReports extentReports;
	@BeforeSuite
	public void setReport() {
		extentReports = ExtentReportsGenerator.initializeReport();

	}

	@BeforeTest
	public void initializeTestData() {

		baseURL = "https://www.redbus.in/";
	}

	public static void initializeTestData(HashMap<String, String> hashMap) {

		baseURL = "https://www.redbus.in/";
		sourceLocation = hashMap.get("Source Location");
		sourceCity = hashMap.get("Source City");
		destinationLocation = hashMap.get("Destination Location");
		destinationCity = hashMap.get("Destination City");
		travelDate = hashMap.get("Travel Date");

		departureTime = hashMap.get("Departure Time");
		typeOfBus = hashMap.get("Type of Bus");

		emailId  = hashMap.get("Email Id");
		contactNo = hashMap.get("Contact No");

		deckType = hashMap.get("Deck Type");
		testcaseId = hashMap.get("TestcaseNo");
		testDescription	= hashMap.get("Test Description");
	}

	@DataProvider(name = "data")
	public Object[][] readDataFromExcel() throws IOException{

		File file = new File("TestData.xlsx");
		FileInputStream fileInputStream = new FileInputStream(file);

		XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);

		XSSFSheet sheet = workbook.getSheet("Bus");

		int rowCount = sheet.getLastRowNum()+1;
		XSSFRow firstRow = sheet.getRow(0);
		System.out.println("Row Count "+rowCount);

		Object[][] objects = new Object[rowCount-1][1];

		for(int i=1;i<rowCount;i++) {
			HashMap<String, String> hashMap = new HashMap<String, String>();
			XSSFRow row = sheet.getRow(i);

			int cellCount = row.getLastCellNum();
			for(int j=0;j<cellCount;j++) {
				hashMap.put(firstRow.getCell(j).getStringCellValue(),row.getCell(j).getStringCellValue());
			}
			objects[i-1][0] = hashMap;

		}

		workbook.close();

		return objects;
	}

	@BeforeMethod
	public void setupDriver() {
		WebDriverManager.firefoxdriver().setup();

		FirefoxOptions options = new FirefoxOptions();
		options.addArguments("--start-maximized","--disable-notifications");
		options.setProfile(new FirefoxProfile());
		options.addPreference("dom.webnotifications.enabled", false);

		driver = new FirefoxDriver(options);

		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		homePage = new HomePage(driver);
		bookSeatPage = new BookSeatPage(driver);
		passengerDetailsPage = new PassengerDetailsPage(driver);

		driver.get(baseURL);
	}

	@AfterMethod
	public void closeBrowser() {
		driver.close();
	}

	@AfterSuite
	public void tearDown() {
		extentReports.flush();
	}
}

