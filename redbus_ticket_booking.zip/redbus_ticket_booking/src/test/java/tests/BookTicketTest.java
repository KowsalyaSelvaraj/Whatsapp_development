package tests;

import java.util.HashMap;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import utils.ExtentReportsGenerator;

public class BookTicketTest extends BaseTest{

	ExtentTest test;

	@Test(dataProvider = "data")
	public void bookTicket(HashMap<String, String> hashMap) throws InterruptedException {

		initializeTestData(hashMap);
		test = extentReports.createTest(testcaseId, testDescription);

		try {
			ExtentReportsGenerator.addResult(test,"Info","Starting test case "+testcaseId);

			homePage.enterSourceLocation(sourceCity,sourceLocation);
			homePage.enterDestinationLocation(destinationCity,destinationLocation);
			homePage.enterTravelDate(travelDate);
			ExtentReportsGenerator.addResult(test,"Pass","Entered Source, destination places and travel date");

			homePage.seachForBuses();

			bookSeatPage.acceptNotifications();
			bookSeatPage.filterByDepartureTime(departureTime);
			bookSeatPage.filterByBusType(typeOfBus);
			ExtentReportsGenerator.addResult(test,"Pass","Filter Applied on Departure Time and Bus Type");

			bookSeatPage.sortByRatings();
			ExtentReportsGenerator.addResult(test,"Pass","Sorted by Ratings");
			
			bookSeatPage.validateBusCount(test);

			bookSeatPage.viewAndBookSeat(deckType);
			ExtentReportsGenerator.addResult(test,"Pass","In Deck "+deckType+" seat has been booked");
		
			bookSeatPage.enterFromAndToPlaces(sourceLocation,destinationLocation);

			passengerDetailsPage.enterPassengerDetails(emailId,contactNo,test);
		
			bookSeatPage.clearFilter();

			ExtentReportsGenerator.addResult(test,"Pass","All Filter Cleared");
	
			ExtentReportsGenerator.addResult(test,"Info","Completed test case "+testcaseId);
			
		}catch (Exception e) {
			ExtentReportsGenerator.addResult(test,"Fail","Exception occured "+e.getMessage());
			e.printStackTrace();
		}
	}

}
