package applicationcode;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.locks.Condition;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.errorprone.annotations.CanIgnoreReturnValue;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RunCode {

	public static String baseURL;
	public static String sourceLocation;
	public static String sourceCity;

	public static String destinationLocation;
	public static String destinationCity;
	public static String travelDate;

	public static String departureTime;
	public static String typeOfBus;

	public static String emailId;
	public static String contactNo;

	public static String deckType;


	public static void main(String[] args) throws InterruptedException {

		initializeData();

		WebDriverManager.firefoxdriver().setup();

		FirefoxOptions options = new FirefoxOptions();
		options.addArguments("--start-maximized","--disable-notifications");
		options.setProfile(new FirefoxProfile());
		options.addPreference("dom.webnotifications.enabled", false);

		WebDriver driver = new FirefoxDriver(options);

		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		//	driver.navigate().to(baseURL);
		driver.get(baseURL);
		if(sourceLocation.equals("")) {
			driver.findElement(By.id("src")).sendKeys(sourceCity);
		}else {
			driver.findElement(By.id("src")).sendKeys(sourceLocation);
		}

		//driver.switchTo().alert().accept();

		//	List<WebElement> sourceLocations = driver.findElements(By.xpath("//*[text()='From']//following::ul/li//text[contains(@class,'MainText')]"));

		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(15));

		//	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[text()='From']//following::ul/li//following::text[contains(@class,'MainText')]"))));
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[text()='From']//following::ul/li//text[contains(@class,'MainText')]"))));
		List<WebElement> sourceLocations = driver.findElements(By.xpath("//*[text()='From']//following::ul/li"));

		for(WebElement element: sourceLocations) {
			System.out.println(element.getText());

			if(sourceCity.isEmpty()) {
				if(element.getText().contains(sourceLocation)) {
					System.out.println(element.getText()+" selected");
					element.click();
					break;
				}
			}else if(sourceLocation.isEmpty()) {
				if(element.getText().contains(sourceCity)) {
					System.out.println(element.getText()+" selected");
					element.click();
					break;
				}
			}else {
				if(element.getText().contains(sourceCity) && element.getText().contains(sourceLocation)) {
					System.out.println(element.getText()+" selected");
					element.click();
					break;
				}
			}
		}

		//destination location
		if(destinationLocation.equals("")) {
			driver.findElement(By.id("dest")).sendKeys(destinationCity);
		}else {
			driver.findElement(By.id("dest")).sendKeys(destinationLocation);
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[text()='To']//following::ul/li//text[contains(@class,'MainText')]"))));
		List<WebElement> destinationLocations = driver.findElements(By.xpath("//*[text()='To']//following::ul/li"));

		for(WebElement destination: destinationLocations) {
			System.out.println(destination.getText());

			if(destinationCity.isEmpty()) {
				if(destination.getText().contains(destinationLocation)) {
					System.out.println(destination.getText()+" selected");
					destination.click();
					break;
				}
			}else if(destinationLocation.isEmpty()) {
				if(destination.getText().contains(destinationCity)) {
					System.out.println(destination.getText()+" selected");
					destination.click();
					break;
				}
			}else {
				if(destination.getText().contains(destinationCity) && destination.getText().contains(destinationLocation)) {
					System.out.println(destination.getText()+" selected");
					destination.click();
					break;
				}
			}
		}


		//	for(WebElement sourceElement : sourceLocations) {
		//		System.out.println(sourceElement.getText());
		//		WebElement subTextElement = sourceElement.findElement(By.xpath("//following-sibling::text[contains(@class,'SubText')]"));
		//		System.out.println(subTextElement.getText());			
		//		if(sourceElement.getText().contains(sourceLocation)) {
		//			subTextElement = sourceElement.findElement(By.xpath("//following-sibling::text[contains(@class,'SubText')]"));
		//			if(!sourceCity.isEmpty() && subTextElement.getText().contains(sourceCity)) {
		//				sourceElement.click();
		//			}else {
		//				sourceElement.click();
		//
		//			}
		//			break;
		//		}
		//}


		//select date

		driver.findElement(By.className("labelCalendarContainer")).click();

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[contains(@class,'CalendarHeader')]/div[2]"))));

		String date = travelDate.split("-")[0];
		String monthString = travelDate.split("-")[1];
		String yearString = travelDate.split("-")[2];
		boolean conditionMatched = true;
		//header date and year
		String monthAndYear =  driver.findElement(By.xpath("//*[contains(@class,'CalendarHeader')]/div[2]")).getText();
		System.out.println(monthAndYear);
		System.out.println("Month "+monthString);
		System.out.println("Year "+yearString);
		while (conditionMatched) {
			if(monthAndYear.contains(monthString) && monthAndYear.contains(yearString)) {
				driver.findElement(By.xpath("//span[contains(@class,'CalendarDaysSpan') and   text()='"+date+"']")).click();
				conditionMatched = false;
			}else {
				driver.findElement(By.xpath("//*[contains(@class,'CalendarHeader')]/div[3]")).click();
				monthAndYear =  driver.findElement(By.xpath("//*[contains(@class,'CalendarHeader')]/div[2]")).getText();
				System.out.println(monthAndYear);
			}
		}

		//click on search button
		driver.findElement(By.id("search_button")).click();



		//in Page two 
		WebElement modifyElement = driver.findElement(By.xpath("//*[text()='Modify']"));
		wait.until(ExpectedConditions.visibilityOf(modifyElement));

		WebElement popUpImportantTipElement = driver.findElement(By.xpath("//span[contains(text(),'Ok, got it')]"));
		Thread.sleep(6000);
		scrollIntoViewElement(driver, popUpImportantTipElement);
		wait.until(ExpectedConditions.visibilityOf(popUpImportantTipElement));
		popUpImportantTipElement.click();

		//
		//	WebElement intoPrimoElement =  driver.findElement(By.xpath("//i[@class='icon icon-close']"));
		try {
			if(driver.findElement(By.xpath("//i[@class='icon icon-close']")).isDisplayed()) {
				driver.findElement(By.xpath("//i[@class='icon icon-close']")).click();
			}
		}catch (Exception e) {
			System.out.println("No Pop up displayed");
		}

		WebElement departureTimeElement = driver.findElement(By.xpath("//*[text()='DEPARTURE TIME']//following::label[contains(@title,'"+departureTime+"')][1]"));
		//*[text()='DEPARTURE TIME']//following::input[@type='checkbox' and contains(@id,'"+departureTime+"')][1]"
		//"//*[text()='DEPARTURE TIME']//following::label[contains(@title,'Before 6 am')][1]"
		scrollIntoViewElement(driver, departureTimeElement);
		departureTimeElement.click();

		WebElement busTypeElement = driver.findElement(By.xpath("//*[text()='BUS TYPES']//following::label[contains(@class,'checkbox') and contains(@for,'"+typeOfBus+"')]"));
		scrollIntoViewElement(driver, busTypeElement);
		busTypeElement.click();

		List<WebElement> resultsElements = driver.findElements(By.xpath("//div[contains(@class,'new-msg')]"));


		WebElement totalNoOfBusesFoundElement = driver.findElement(By.xpath("//span[contains(@class,'found')]"));
		System.out.println("Total Number of Buses Found "+totalNoOfBusesFoundElement.getText());

		for(WebElement resultMessage: resultsElements) {
			System.out.println(resultMessage.getText());
			if(resultMessage.getText().contains("0")) {
				System.out.println("No Buses Found for the filter criteria");
			}else {
				System.out.println("No of Buses for filter criteria is "+resultMessage.getText().split(" ")[0]);
			}
		}


		//order by bus rating 
		WebElement orderByRatingElement = driver.findElement(By.xpath("//a[text()='Ratings']"));
		scrollIntoViewElement(driver, orderByRatingElement);
		orderByRatingElement.click();

		//Bus details on top
		WebElement topBusNamElement = driver.findElement(By.xpath("//div[contains(@class,'two')]/div[contains(@class,'travels')]"));

		System.out.println("Top Rated Bus name "+topBusNamElement.getText());

		//view and book seat
		WebElement viewSeatElement = driver.findElement(By.xpath("//div[contains(@class,'button view-seats')]"));
		//	scrollIntoViewElement(driver, viewSeatElement);
		viewSeatElement.click();
		Thread.sleep(5000);
		//book seat
		Actions actions = new Actions(driver);

		WebElement canvasElement;
		if(deckType.equalsIgnoreCase("lower")) {

			selectSeatFromDeck(driver,deckType.toLowerCase());
		}else if (deckType.equalsIgnoreCase("upper")) {
			selectSeatFromDeck(driver,deckType.toLowerCase());
		}else if(deckType.equalsIgnoreCase("No Preference")){
			selectSeatFromDeck(driver,"lower");
		}
		//			canvasElement = driver.findElement(By.xpath("//canvas[@data-type='lower']"));
		//
		//			int canvas_X =	canvasElement.getSize().getWidth();
		//			int canvas_Y = canvasElement.getSize().getHeight();
		//
		//			System.out.println(canvas_X+" X "+canvas_Y+" Y");
		//			//actions.moveToElement(canvasElement, canvas_X, canvas_Y).build().perform();
		//
		//			String seatSelected = "No";
		//
		//			for(int i =0;i<canvas_X;i++) {
		//				for(int j=0;j<canvas_Y;j++) {
		//					actions.moveToElement(canvasElement, i, j).build().perform();
		//					canvasElement = driver.findElement(By.xpath("//canvas[@data-type='lower']"));
		//					System.out.println("X pointer "+i+" Y pointer "+j);
		//					System.out.println(canvasElement.getAttribute("class")+"is the pointer info");
		//					if(canvasElement.getAttribute("class").equalsIgnoreCase("pointer")) {
		//						actions.click().build().perform();
		//						seatSelected = "Yes";
		//						break;
		//					}
		//				}
		//
		//				if(seatSelected.equalsIgnoreCase("Yes")) {
		//					break;
		//				}
		//			}


		//select boarding point 

		//div[contains(@class,'bpDpAddr-css')]/span
		WebElement selectBpDp = driver.findElement(By.xpath("//div[@class='selectBpDpHeading']"));
		scrollIntoViewElement(driver, selectBpDp);

		if(!sourceLocation.equalsIgnoreCase("")) {

			List<WebElement> boardingPointsElements = driver.findElements(By.xpath("//ul[@data-value='bp']//div[contains(@class,'bpDpAddr-css')]"));

			for(WebElement boardingElement : boardingPointsElements) {

				if(boardingElement.getText().contains(sourceLocation)) {
					//	boardingElement.findElement(By.xpath("//preceding-sibling::div/div")).click();
					boardingElement.click();
					break;
				}
			}	
		}else {
			WebElement boardingPointElement = driver.findElement(By.xpath("//ul[@data-value='bp']//div[contains(@class,'bpDpAddr-css')]//preceding-sibling::div/div"));
			boardingPointElement.click();
		}

		//select dropping point in header
		WebElement dropingPointHeaderElement = driver.findElement(By.xpath("//span[text()='DROPPING POINT']"));
		dropingPointHeaderElement.click();

		if(!destinationLocation.equalsIgnoreCase("")) {

			List<WebElement> dropingPointsElements = driver.findElements(By.xpath("//ul[@data-value='dp']//div[contains(@class,'bpDpAddr-css')]"));

			for(WebElement dropingElement : dropingPointsElements) {

				if(dropingElement.getText().contains(destinationLocation)) {
					dropingElement.click();
					break;
				}
			}	
		}else {
			WebElement dropingPointElement = driver.findElement(By.xpath("//ul[@data-value='dp']//div[contains(@class,'bpDpAddr-css')]//preceding-sibling::div/div"));
			dropingPointElement.click();
		}


		WebElement proceedBookingButtonElement = driver.findElement(By.xpath("//button[text()='Proceed to book']"));

		WebElement boardingAndDropingTextElement = driver.findElement(By.xpath("//span[@class='bpdp-lb']"));
		scrollIntoViewElement(driver, boardingAndDropingTextElement);
		waitAndClickElement(driver,proceedBookingButtonElement);


		WebElement passengerDetailsElement = driver.findElement(By.xpath("//*[text()='Passenger Details']"));
		waitForVisibilityOfElement(driver, passengerDetailsElement);

		WebElement contactDetailsElement = driver.findElement(By.xpath("//span[text()='Contact Details']"));

		scrollIntoViewElement(driver, contactDetailsElement);

		WebElement emailElement = driver.findElement(By.xpath("//*[text()='Email ID']/input"));
		sendDataToField(driver, emailElement, emailId);

		WebElement contactNoElement = driver.findElement(By.id("seatno-06"));
		sendDataToField(driver, contactNoElement, contactNo);


		WebElement backButtonElement = driver.findElement(By.xpath("//*[@title='Back']"));
		waitAndClickElement(driver, backButtonElement);

		WebElement clearAllFiltersElement = driver.findElement(By.xpath("//button[text()='CLEAR ALL FILTERS']"));

		waitAndClickElement(driver, clearAllFiltersElement);


		//		String seatSelected = "No";
		//		while(seatSelected.equalsIgnoreCase("No") && canvas_X>0 && canvas_Y>0) {
		//			if(canvasElement.getAttribute("class").equals("pointer")) {
		//				actions.moveToElement(canvasElement, canvas_X, canvas_Y/2).click().build().perform();
		//				seatSelected = "Yes";
		//				System.out.println("seat selected");
		//			}else {
		//				canvas_X = canvas_X -1;
		//				actions.moveToElement(canvasElement, canvas_X, canvas_Y/2).build().perform();
		//				canvasElement = driver.findElement(By.xpath("//canvas[@data-type='lower']"));
		//				System.out.println("move to element "+canvas_X+"=> "+canvas_Y);
		//			}
		//		}
	}



	public static void selectSeatFromDeck(WebDriver driver, String deckType) {
		// TODO Auto-generated method stub
		WebElement canvasElement = driver.findElement(By.xpath("//canvas[@data-type='"+deckType+"']"));
		Actions actions = new Actions(driver);
		int canvas_X =	canvasElement.getSize().getWidth();
		int canvas_Y = canvasElement.getSize().getHeight();

		System.out.println(canvas_X+" X "+canvas_Y+" Y");
		//actions.moveToElement(canvasElement, canvas_X, canvas_Y).build().perform();

		String seatSelected = "No";

		for(int i =0;i<canvas_X;i++) {
			for(int j=0;j<canvas_Y;j++) {
				actions.moveToElement(canvasElement, i, j).build().perform();
				canvasElement = driver.findElement(By.xpath("//canvas[@data-type='"+deckType+"']"));
				System.out.println("X pointer "+i+" Y pointer "+j);
				System.out.println(canvasElement.getAttribute("class")+"is the pointer info");
				if(canvasElement.getAttribute("class").equalsIgnoreCase("pointer")) {
					actions.click().build().perform();
					seatSelected = "Yes";
					break;
				}
			}

			if(seatSelected.equalsIgnoreCase("Yes")) {
				break;
			}
		}
	}



	public static void initializeData() {

		baseURL = "https://www.redbus.in/";
		sourceLocation = "Anna Nagar";
		sourceCity = "Chennai";
		destinationLocation = "Silk Board";
		destinationCity = "Bangalore";
		travelDate = "2-Feb-2024";

		departureTime = "After 6 pm";
		typeOfBus = "AC";


		emailId  = "kowsalya@gmail.com";
		contactNo = "9865412584";

		deckType = "upper";

	}

	public static void scrollIntoViewElement(WebDriver driver,WebElement element) {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

		jsExecutor.executeScript("arguments[0].scrollIntoView(true)",element);

	}

	public static void waitAndClickElement(WebDriver driver,WebElement element) {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		wait.until(ExpectedConditions.elementToBeClickable(element));

		element.click();
	}

	public static void waitForVisibilityOfElement(WebDriver driver,WebElement element) {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		wait.until(ExpectedConditions.visibilityOf(element));

		element.click();
	}

	public static void sendDataToField(WebDriver driver,WebElement element,String value) {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		wait.until(ExpectedConditions.visibilityOf(element));

		element.sendKeys(value);
	}
}
