package utils;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import pages.BasePage;

public class ExtentReportsGenerator {


	public static ExtentReports initializeReport() {

		ExtentSparkReporter htmlReporter = new ExtentSparkReporter("extent-reports/TestExecutiontReport_"+DateUtil.getCurrentTime()+".html");
		//create ExtentReports and attach reporter(s)
		ExtentReports extentReports = new ExtentReports();

		htmlReporter.config().setReportName("Red Bus - Book Ticket");
		extentReports.attachReporter(htmlReporter);
		extentReports.setSystemInfo("Executor", "User1");

		return extentReports;
	}



	public static void addResult(ExtentTest test, String type,String stepDescription) {

		String resultTypeString= type.toUpperCase();
		String screenshotPathString="";
		switch (resultTypeString) {
		case "PASS":
			screenshotPathString = ScreenShotGenerator.getScreenshot(BasePage.driver);
			test.pass(stepDescription, MediaEntityBuilder.createScreenCaptureFromPath(screenshotPathString).build());
			break;
			
		case "FAIL":
			screenshotPathString = ScreenShotGenerator.getScreenshot(BasePage.driver);
			test.fail(stepDescription, MediaEntityBuilder.createScreenCaptureFromPath(screenshotPathString).build());
			break;

		case "INFO":
			test.info(stepDescription);
			break;
			
		default:
			break;
		}

	}
}
