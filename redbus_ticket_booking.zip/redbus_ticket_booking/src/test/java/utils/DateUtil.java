package utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

	
	
	public static String getCurrentTime() {
		Date date = new Date();  
	    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");  
	    String strDate= formatter.format(date);  
	    System.out.println(strDate);
	    return strDate;
	}
	
	public static void main(String[] args) {
		getCurrentTime();
	}
}
