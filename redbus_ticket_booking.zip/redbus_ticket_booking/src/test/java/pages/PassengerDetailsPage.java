package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import utils.ExtentReportsGenerator;

public class PassengerDetailsPage extends BasePage{

	public PassengerDetailsPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(BasePage.driver, this);
	}
	
	@FindBy(xpath = "//*[text()='Passenger Details']")
	private static WebElement passengerDetailsElement;

	@FindBy(xpath = "//span[text()='Contact Details']")
	private static WebElement contactDetailsElement;

	@FindBy(xpath = "//*[text()='Email ID']/input")
	private static WebElement emailElement;

	@FindBy(id = "seatno-06")
	private static WebElement contactNoElement;
	
	@FindBy(xpath = "//*[@title='Back']")
	private static WebElement backButtonElement;
	
	//getters and Setters
	public static WebElement getPassengerDetailsElement() {
		return passengerDetailsElement;
	}

	public static void setPassengerDetailsElement(WebElement passengerDetailsElement) {
		PassengerDetailsPage.passengerDetailsElement = passengerDetailsElement;
	}

	public static WebElement getContactDetailsElement() {
		return contactDetailsElement;
	}

	public static void setContactDetailsElement(WebElement contactDetailsElement) {
		PassengerDetailsPage.contactDetailsElement = contactDetailsElement;
	}

	public static WebElement getEmailElement() {
		return emailElement;
	}

	public static void setEmailElement(WebElement emailElement) {
		PassengerDetailsPage.emailElement = emailElement;
	}

	public static WebElement getContactNoElement() {
		return contactNoElement;
	}

	public static void setContactNoElement(WebElement contactNoElement) {
		PassengerDetailsPage.contactNoElement = contactNoElement;
	}

	public static WebElement getBackButtonElement() {
		return backButtonElement;
	}

	public static void setBackButtonElement(WebElement backButtonElement) {
		PassengerDetailsPage.backButtonElement = backButtonElement;
	}
	
	//Methods
	//entering passenger details 
	public void enterPassengerDetails(String emailId, String contactNo,ExtentTest test) {
		
		waitForVisibilityOfElement( getPassengerDetailsElement());
		scrollIntoViewElement(driver, getContactDetailsElement());
		
		sendDataToField(getEmailElement(), emailId);
		sendDataToField(getContactNoElement(), contactNo);
		ExtentReportsGenerator.addResult(test,"Pass","Entered Passenger Details");
		
		waitAndClickElement(getBackButtonElement());
		
	}

	

}
